package commande;

public class CommandeExeption extends Exception{
	
	public CommandeExeption(){
		System.out.println("Cette commande n'exixte pas ");
	}


}
