package ihm;

import java.awt.Dimension;

import javax.swing.JLabel;

public class jTextLabelCurseur extends JLabel {

	public jTextLabelCurseur() {
		super();
		this.setPreferredSize(new Dimension(70, Fenetre.JPanelParametres
				.getHeight()));
	}

}
