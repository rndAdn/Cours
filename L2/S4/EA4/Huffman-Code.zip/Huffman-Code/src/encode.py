def creerDico(texte):
	d = dict()
	for c in texte:
		d[c] = d.get(c,0) + 1
	return d

class tasMin(list):
	def __init__(self,dico):
		T = [ArbreHauff(fre=v,char=k) for (k,v) in dico.items()]
		self.extend(self.creer_tas_min(T))

	def creer_tas_min(self,T) :
		for i in range(len(T)//2, -1, -1) :
			self.entasser_min(T, i)
		return T

	def entasser_min(self,T, i) :
		min, l, r = i, 2*i+1, 2*i+2
		if l < len(T) and T[l].freq < T[min].freq : min = l
		if r < len(T) and T[r].freq < T[min].freq : min = r
		if min != i :
			T[i], T[min] = T[min], T[i]
			self.entasser_min(T, min)

	def extraction_min(self) :
		max = self[0]
		self[0] = self.pop()
		self.entasser_min(self, 0)
		return max

	def ajouter(self,element):
		self.insert(0,element)
		self.entasser_min(self, 0)


class ArbreHauff():
	def __init__(self,fre,gauche=None,droit=None,char=None):
		self.freq = fre
		self.gauche = gauche
		self.droit = droit
		self.char = char

	def __repr__(self):
		return str(self.freq)


t = creerDico("plouf badaboumazertbnngcfxdw")
print(t)
test = tasMin(t)
print(test)