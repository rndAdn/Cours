'''

'''
import re


regexTab = ['e', r"[ÉÈÊËéèêë]"],\
           ['a', r"[ÀàÂâÄä]"],\
           ['u', r"[ÙùüÜÛû]"],\
           ['i', r"[ÌÍÎÏìíîï]"],\
           ['o', r"[òóôõöÒÓÔÕÖ]"],\
           ['c', r"[çÇ]"]

DicoBinaire = dict()


def doRegex(txt):
    for elt in regexTab:
        expression = re.compile(elt[1])
        motList = [word for word in expression.findall(txt)]
        for mot in motList:
            txt = txt.replace(mot, elt[0])
    return txt

class Noeud:
    '''
    Dans cette classe les mots Feuille et Arbre corresponde au meme objet la distinction est :
    Une Feuille n'a ni gauche ni droit  mais elle possède un char avec sa frequence
    Un  Arbre n'a pas de char et sa freq correspond a la frequence des char ces sous Arbres/Feuille


    '''



    def __init__(self, freq,gauche=None,droit=None, char=None):
        self.freq = freq
        self.gauche=gauche
        self.droit = droit
        self.char = char


    def ArbreToDict(self, ch=""):
        if self.char:
            DicoBinaire[self.char] = ch
            return

        self.gauche.ArbreToDict(ch + "0")
        self.droit.ArbreToDict(ch + "1")

    def __repr__(self):

        if self.char:
            return "{0} char:{1} g:{2} d:{3}  ".format(self.freq,self.char, self.gauche, self.droit)
        else:
            return "{0} char:{1} g:{2} d:{3}  ".format(self.freq, self.char, self.gauche, self.droit)


def freqToArbre(freqTableau):

    '''
    Cette Fonction est la fonction pricipale de la transformation d'un tableau de frequence
    en un arbre binaire
    Elle va dabord tranformer le tableau de frequence en tableau de feuille TRIÉE
    Puis appeler sa fonction recusive toArbreRec
    La frequence est un tuple ('c', 0)
    '''

    Feuilles = []
    for tup in freqTableau:
        Feuilles += [Noeud(tup[1],char=tup[0])]
    return toArbreRec(Feuilles)


def toArbreRec(freqFeuille):
    '''
    Tant que le tableau a plus de deux éléments on retire les deux Feuille/Arbre avec les plus petites frequences
    Puis on tranforme ces Feuille/Arbre en un autre Arbre (la plus petite frequence dès deux se trouve a gauche)
    Le nouvel Arbre est ensuite rajouté au tableau classé
    '''
    if len(freqFeuille) > 1:
        n1 = freqFeuille[0]
        n2 = freqFeuille[1]
        ar = Noeud(n1.freq+n2.freq, gauche=n1, droit=n2)
        freqFeuille = freqFeuille[2:]
        for i,elt in enumerate(freqFeuille):
            if ar.freq < elt.freq:
                freqFeuille = freqFeuille[:i]+[ar]+freqFeuille[i:]

                return toArbreRec(freqFeuille)
        freqFeuille  += [ar]
        return toArbreRec(freqFeuille)
    return freqFeuille[0]

def txtToFreq(txt):
    '''
    On cree un dictionnaire de lettre:occurence
    Ensuite on parcours le texte en remplissant le dictionnaire et on le renvoi

    '''
    dico = dict()

    for lettre in txt:
        dico[lettre] = dico.get(lettre, 0) + 1

    return list(dico.items())

def encode(txt):
    '''

    '''

    freqTab = txtToFreq(txt)
    freqTab.sort(key=lambda x: x[1])


    arbre = freqToArbre(freqTab)
    arbre.ArbreToDict()

    txt_encode = ""

    print("Dictionnaire de frequence et représentation binaire")
    for elt in freqTab:
        print(str(elt) + "\t : " + DicoBinaire[elt[0]])


    for c in txt:
        txt_encode += DicoBinaire[c]

    return txt_encode


def decode(txt):
    '''

    '''
    Dico = dict(zip(DicoBinaire.values(), DicoBinaire.keys()))
    txt_decode = ""
    tmp = ""

    for bit in txt:
        tmp += bit
        if tmp in Dico:
            txt_decode += Dico[tmp]
            tmp = ""

    return txt_decode

path = "../dr"
fichier = open(path)
txt = [l for l in fichier.readlines()]
txt = "".join(txt)
#txt = "azercydsaaazer"


print("texte :\n"+txt+"\n")

'''
txt = doRegex(txt)
txt = txt.lower()
print("texte Regex:\n"+txt+"\n")
'''


encode = encode(txt)
print("encode :\n"+encode+"\n")


decode = decode(encode)

lenor = len(txt)*8
lenen = len(encode)

print("decode :\n"+decode)
print("\ntaille normal :"+str(lenor)+"\ttaille compréssé :"+str(lenen))
print("gagné "+str((lenor)-(lenen))+" bits")


print("\n\ntaille normal :"+str(lenor//8) + "\ttaille compréssé :"+str(lenen//8))
print("gagné "+str((lenor//8)-(lenen//8))+" octets\n")

ratio = (lenen)/(lenor)
print("Ratio : %.2f" % (100-ratio*100)+" %")


print("egal ?  "+str(txt==decode))