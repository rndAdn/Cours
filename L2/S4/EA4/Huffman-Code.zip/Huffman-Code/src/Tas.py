
def gauche(i):
    return (2*i) + 1


def droit(i):
    return (2*i) + 2


def entasse(Tas, i):
    max = i
    gaucheI = gauche(i)
    droitI = droit(i)
    if gaucheI < len(Tas) and Tas[gaucheI] > Tas[i]:
        max = gaucheI
    if droitI < len(Tas) and Tas[droitI] > Tas[max]:
        max = droitI
    if max != i:
        Tas[max] , Tas[i] = Tas[i], Tas[max]
        entasse(Tas, max)

def entasser_max(T, i) :
    max, l, r = i, 2 * i + 1, 2 * i + 2
    if l < len(T) and T[l] > T[max]: max = l
    if r < len(T) and T[r] > T[max]: max = r
    if max != i:
        T[i], T[max] = T[max], T[i]
        entasser_max(T, max)


def creer_tas_max(T):
    for i in range(len(T) // 2, -1, -1):  # parcours à l’envers
        entasse(T, i)
        #entasser_max(T, i)






tab = [1,2,3,4,8,5,19,27,51]
print(tab)
creer_tas_max(tab)
print(tab)
