Huffman-Code
============

(TP noté) Ls4
