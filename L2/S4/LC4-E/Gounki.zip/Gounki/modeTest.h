/*
   //  modeTest.h
   //  ProjetRC
   //
   //  Created by Etienne Toussaint on 10/05/2014.
   //  Copyright (c) 2014 Etienne Toussaint. All rights reserved.
 */

#ifndef ProjetRC_modeTest_h
#include "pion.h"
#include "grille.h"
#include "Jouer.h"
#include <string.h>
#define ProjetRC_modeTest_h
void modeTest(const char * name);


#endif
