#include <stdio.h>

struct fraction {
	long long int num;
	long long int den;
};

typedef struct fraction fraction;
