//
//  alloc.h
//  TP7
//
//  Created by Etienne Toussaint on 12/03/2014.
//  Copyright (c) 2014 Etienne Toussaint. All rights reserved.
//

#ifndef TP7_alloc_h
#define TP7_alloc_h

#define N 1024

void toPrint();
void *my_alloc(int x);
void my_free(void * mem);

#endif
