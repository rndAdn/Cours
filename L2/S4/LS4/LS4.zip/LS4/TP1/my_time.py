#my_time.py

def sec_to_hms(sec):
    ''' retourne le temps correspondant en (h,m,s)'''
    pass

def hms_to_sec(h, m, s):
    '''retourne le temps correspondant en seconde'''
    pass

def now():
    ''' utilise le module time pour donner l'heure sous la forme (h, m, s)'''
    pass

if __name__== "__main__":
    print("ici j'écrirai l'heure")
