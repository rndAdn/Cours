# NE PAS MODIFIER CES INFORMATIONS
# Nom: ADEQUIN renaud
# Numero etudiant: 21001718
# Numero sujet 89131
# Mon, 05 May 2014 09:04:06 172.28.135.185
# NE PAS CHANGER LES NOMS DES FONCTIONS

# Exercice 1
def ex088(l):
    '''
    OK
    '''
    if not l:
        return (None, 0, [])

    l.sort(key=lambda x:x[1])
    return (l[0][0],l[0][1], l[1:])
    pass


####
# Exercice 2
def ocb99(s):
    tab = []
    for c in s:
        IN = False
        for t in tab:
            if c == t[0]:
                t[1] += 1
                IN = True
                break
        if not IN:
            tab += [[c, 1]]
    return [(x[0], x[1]) for x in tab]

def fp736(s):
    f = len(s)
    tab = []
    for c in s:
        IN = False
        for t in tab:
            if c == t[0]:
                t[1] += 1
                IN = True
                break
        if not IN:
            tab += [[c, 1]]
    return [(x[0], round(x[1]/f,3)) for x in tab]

####
# Exercice 3
def insd2c(c, r, l):

    return l+[(c,r)]
    pass

####
# Exercice 4
# Classe Noeud:

class Noeud:
    def __init__(self,v=None):
        self.val = v
        self.fg = None
        self.fd = None

    def __str__(self, d=""):
        s = self.val
        d+="\t"
        if self.fg:
            s+= "\n"+d+self.fg.__str__(d=d)
        else:
            s+= "\n"+d+" fg vide"
        if self.fd:
            s+= "\n"+d+self.fd.__str__(d=d)
        else:
            s+= "\n"+d+" fd vide"
        return s

# Exemples d'arbres
a1 = Noeud('a')

a2 = Noeud('a')
a2.fd = Noeud('a')

a3 = Noeud('cb')
a3.fg =  Noeud('c')
a3.fd =  Noeud('b')

a4 = Noeud('cbd')
a4.fg = Noeud('c')
a4.fd = Noeud('bd')
a4.fd.fg = Noeud('b')
a4.fd.fd = Noeud('d')


# Fonctions à implémenter

def cf90c(s, d):
    arbreTmp = d
    ch = ""
    while s in arbreTmp.val:
        if s == arbreTmp.val and arbreTmp.fg == None and arbreTmp.fd == None:
            return ch
        if arbreTmp.fg and s in arbreTmp.fg.val:
            arbreTmp = arbreTmp.fg
            ch += '0'
        elif arbreTmp.fd and s in arbreTmp.fd.val:
            arbreTmp = arbreTmp.fd
            ch += '1'




    pass

def ca6c5(d):
    Dico = dict()
    def rec(d, ch=""):
        if not d:
            return
        if len(d.val) == 1 and d.fg == None and d.fd == None:
            Dico[d.val] = ch
            return
        rec(d.fg, ch+'0')
        rec(d.fd, ch+'1')


    rec(d)
    return Dico

# Algorithme de Huffman
def huffman(nf):
    t = open(nf).read().strip()
    n = len(set(t))
    d = {s:t.count(s)/n for s in t}
    f = sorted(d.items(), key=lambda x:x[1])
    for i in range(n-1):
        (t1, f1) = f[0]
        (t2, f2) = f[1]
        if type(t1) == str:
            fg = Noeud(t1)
        else: 
            fg = t1
        if type(t2) == str:
            fd = Noeud(t2)
        else: 
            fd = t2
        a = Noeud(fg.val+fd.val)
        a.fg =fg
        a.fd = fd
        del f[0:2]
        j, l = 0, len(f)
        while j<l and f[j][1]<f1+f2:
            j +=1    
        f.insert(j, (a, f1+f2))
    return f[0][0]


####
# Exercice 5
def mibeb(d):
    return dict(zip(d.values(), d.keys()))
    pass

def de74c(s, d):

    decode = ""
    tmp = ""
    for c in s:
        tmp += c
        if tmp in d:
            decode += d[tmp]
            tmp = ""
    return decode

####
# Exercice 6
def liacf(f):
    return  open(f).read().strip()

    return ch
def encf2(f):
    arbre = huffman(f)
    dico = ca6c5(arbre)
    ch = ""
    ch2 = liacf(f)
    for c in ch2:
        ch+= dico[c]


def co68d(f):
    chde = len(liacf(f))*8
    enco = len(encf2(f))
    return str(int((enco/chde)*100))
