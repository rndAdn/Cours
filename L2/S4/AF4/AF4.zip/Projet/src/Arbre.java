import java.util.*;

abstract class Arbre{
	Character symbole;
	Arbre gauche;
	Arbre droit;
	Arbre fils;
	boolean contientMotVide;

	Set<Feuille> premiers = new HashSet<Feuille>();
    Set<Feuille> derniers = new HashSet<Feuille>();
    boolean epsilon = false; // permet de de distinguer le cas (ab + 1) et ab pour le residuel

    /**
     *
     * @return
     */
	abstract Map<Feuille,Set<Feuille>> succ();

    /**
     * Calcul les residuels des Binaire Unaire Et Feuille
     * La methode residuel utilise la meme methode vue en cours
     * @param c
     * @return
     */
    abstract Arbre residuel(char c);

    /**
     * Simplification de l'arbre
     * @return
     */
    abstract Arbre simpleArbre();


    /**
     *
     * @return
     */
    public abstract String toString();

    /**
     *
     * @return
     */
    public abstract HashSet<String> contientArbre();

	static Arbre lirePostfixe(String expresion){
		Stack<Arbre> pileArbre = new Stack<Arbre>();
		for (int i = 0; i < expresion.length(); i++){
			switch(expresion.charAt(i)){
				case'+':
				case'.':
					Arbre pop = pileArbre.pop();
					pileArbre.push(new Binaire(pileArbre.pop(),pop,expresion.charAt(i)));
					break;
				case'*':
					pileArbre.push(new Unaire(pileArbre.pop(),expresion.charAt(i)));
					break;
				default :
					pileArbre.push(new Feuille(expresion.charAt(i)));
					break;
			}
		}
	return pileArbre.pop();
	}

	public boolean egaliteArbre(Arbre arbre){
        /* POur de deux expression on contruit les automates minimales
        pour pouvoir
         */
		Residuel resi1 = new Residuel();
		Residuel resi2 = new Residuel();
		Automate auto1 = resi1.residuelExpression(this);
		Automate auto2 = resi2.residuelExpression(arbre);
		return auto1.egaliteAutomate(auto2);
		
	}

    /**
     * Retourne l'alphabet de l'arbre
     * @return
     */
    public Set<Character> alphabet(){
        Set<Character> resultat = new HashSet<Character>();
        for (Feuille f :this.succ().keySet()){
            resultat.add(f.symbole);
        }
        return resultat;
    }
}
