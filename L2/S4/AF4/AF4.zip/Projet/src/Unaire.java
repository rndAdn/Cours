import java.util.HashSet;
import java.util.Map;
import java.util.Set;

class Unaire extends Arbre{
	
	public String toString() {
        if(this.fils instanceof Feuille)return (fils.toString()+ this.symbole);
        return ("(" + fils.toString() + ")" + this.symbole);
    }
	
	public Unaire(Arbre fils, char s) {
        this.symbole = s;
        this.fils = fils;
        this.contientMotVide= true;
        this.premiers.addAll(this.fils.premiers);
        this.derniers.addAll(this.fils.derniers);
    }
	
    public Map<Feuille, Set<Feuille>> succ() {
    	Map<Feuille, Set<Feuille>> succ = fils.succ();
        for (Feuille f : derniers) {
            succ.get(f).addAll(premiers);
        }
        return succ;
    }

	@Override
	Arbre residuel(char c) { //
        String s = fils.toString();
        String ss = fils.residuel(c).toString();
		if(s.equals(ss) || fils.residuel(c).contientMotVide) // si le residuel de mon fils est égal arbre moi meme je me renvoi
			return this.simpleArbre();
		else
			return new Binaire(fils.residuel(c),this,'.').simpleArbre(); // je renvoi le residuel de mon fils concatener arbre moi-même ex (ab)* ->  b(ab)*
	}
	
	Arbre simpleArbre(){


        if(fils.symbole == '*')return fils.simpleArbre();// si mon fils est un unaire je simplifie mon fils (** = *)

        // dans un unaire on a pas besoin de simplifier la concatenation
        // or (a* + b)* = (a + b)*

        if(fils.symbole == '+'){
			if(fils.gauche.symbole=='*'){
                Arbre gauche = fils.gauche.fils.simpleArbre();
                Arbre droit = fils.droit.simpleArbre();
				Arbre pere = new Unaire(new Binaire(gauche,droit,'+').simpleArbre(),'*');
				return pere.simpleArbre();
			}
			if(fils.droit.symbole=='*'){

                Arbre gauche = fils.gauche.simpleArbre();
                Arbre droit = fils.droit.fils.simpleArbre();
                Arbre pere = new Unaire(new Binaire(gauche,droit,'+').simpleArbre(),'*');
                return pere.simpleArbre();
			}
		}
		return this;
	}

	@Override
	public HashSet<String> contientArbre() {
		HashSet<String> set = new HashSet<String>();
		if(fils.symbole == '+'){
			for(String s : fils.contientArbre())set.add(s.concat(this.symbole.toString()));
		}
		set.add(this.toString());
		return set;
	}
}
