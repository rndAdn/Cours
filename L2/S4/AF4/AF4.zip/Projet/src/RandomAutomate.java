
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;
import java.lang.Math;

public class RandomAutomate {

    private Integer nbEtat;
    private Set<Character> ensLettre = new HashSet<Character>();
    ;

    public RandomAutomate(String en, int nb) {
        this.nbEtat = nb;

        for (int i = 0; i < en.length(); i++) {
            ensLettre.add(en.charAt(i));
        }
    }

    public Automate generer() {
        ArrayList<Etat> etatList = new ArrayList<Etat>();
        boolean term = new  Random().nextInt(10) == 0;
        boolean init;
        etatList.add(new Etat(true, term, 0));
        for (int i = 1; i < nbEtat-1; i++) {
            init = new  Random().nextInt(10) == 0;
            term = new  Random().nextInt(5) == 0;
            etatList.add(new Etat(init, term, i));

        }
        init = new  Random().nextInt(15) == 0;
        etatList.add(new Etat(init, true, nbEtat-1));
        for (int i = 1; i < nbEtat; i++) {
            for (Character l : ensLettre) {
                int nbTran = 1 +new  Random().nextInt(3);
                for (int j = 0; j < nbTran; j++) {
                    int idEtat = new  Random().nextInt(nbEtat);
                    if (idEtat < nbEtat - 1) etatList.get(i).ajouteTransition(l, etatList.get(idEtat));
                }
            }
        }
        Automate auto = new Automate();
        for (Etat e : etatList)
            auto.ajouteEtatSeul(e);

        return auto;
    }
}