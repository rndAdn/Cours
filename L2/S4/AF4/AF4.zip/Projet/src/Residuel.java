import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class Residuel {

	private Map<Arbre, Etat> map = new HashMap<Arbre, Etat>(); // Map de l'arbre represantant une expression associer arbre un état
    private ArrayList<CoupleArbre_Etat> listeAppels = new ArrayList<CoupleArbre_Etat>(); // liste des appel a faire pour garder l'ordre
    private char[] alphabet; // alphabet de l'expression
	
	
	public Automate residuelExpression(Arbre arbreExpr){
        System.out.println("Expression rationnelle :"+arbreExpr+"\n");
		Etat initial = new Etat(true,arbreExpr.contientMotVide,0); // construction de l'état Initial
        alphabet = new char[arbreExpr.alphabet().size()];
        int i = 0;
        for (Character c : arbreExpr.alphabet()){
            alphabet[i++]=c;
        }
        Arrays.sort(alphabet);
		this.map.put(arbreExpr,initial); // on associe arbre l'expression de depart un état initial
		this.residueRecursif(arbreExpr, initial,"");
		Automate automate = new Automate();
		automate.ajouteEtatRecursif(initial);
		return automate;
	}
	
	public void residueRecursif(Arbre arbre, Etat etat, String last){
		for(char l : alphabet){
			Arbre arbreResiuelLettre=arbre.residuel(l);// on calcul le residuel de notre arbre aavec notre lettre l
            System.out.println("(" + last + l + "¯¹) " + arbre.toString() + " = " + arbreResiuelLettre.toString());
			boolean empile= true;
			for(Arbre a : this.map.keySet()){ // dans notre map





                if(a.toString().equals(arbreResiuelLettre.toString())&& // si l'arbre existe deja et
                        (((a.epsilon ||a.contientMotVide)&&(arbreResiuelLettre.epsilon ||arbreResiuelLettre.contientMotVide)) //qu'ils contiennent tous les deux le mot vide OU
                                        ||((!a.contientMotVide&&!a.epsilon)&&(!arbreResiuelLettre.epsilon &&!arbreResiuelLettre.contientMotVide)))){




                    etat.ajouteTransition(l,map.get(a)); // on ajoute arbre l'etat une transition vers l'etat correspondant dans la map
					empile=false; // donc on fera pas de nouvel etat
					break; // et on est pas obligé de continuer
				}
			}
			
			if (empile && arbreResiuelLettre.symbole!='0'){  // si on doit le faire et que notre arbre n'est pas vide
				Etat e = new Etat(false,arbreResiuelLettre.contientMotVide||arbreResiuelLettre.epsilon,map.size());
				etat.ajouteTransition(l,e); // on fait une transition vers l'etat créé
				map.put(arbreResiuelLettre, e); // et on l'ajoute arbre notre map
                if(arbreResiuelLettre.symbole!='1') listeAppels.add(new CoupleArbre_Etat(arbreResiuelLettre, e,last+l)); // si l'arbre n'est pas le mot vide on continue ajoute arbre notre liste le couple suivant arbre faire
			}
		}
        if(!listeAppels.isEmpty()){ // si la liste n'est pas vide on rappel cette fonction recusivement sur le couple
            CoupleArbre_Etat c = listeAppels.get(0);
            listeAppels.remove(0);
			residueRecursif(c.arbre, c.etat, c.l);
		}
	}

    class CoupleArbre_Etat {
        Arbre arbre;
        Etat etat;
        String l;

        public CoupleArbre_Etat(Arbre arbre, Etat e, String l) {
            this.arbre = arbre;
            this.etat =e;
            this.l= l;
        }
    }
}

