import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

class Binaire extends Arbre{ 
	
	public String toString() {
        if (this.symbole == '+')return ('('+gauche.toString() + this.symbole + droit.toString()+')');
        return (gauche.toString()+droit.toString());

    }
	
	public Binaire(Arbre gauche, Arbre droit, char s) {
        this.gauche = gauche;
        this.droit = droit;
        this.symbole = s;
        this.contientMotVide = ((this.gauche.contientMotVide||this.droit.contientMotVide||this.droit.epsilon ||this.gauche.epsilon)&&s=='+') || (((this.gauche.contientMotVide||this.gauche.epsilon)&&(this.droit.contientMotVide||this.droit.epsilon))&&s=='.');
        if(s=='+'){
        	this.premiers.addAll(this.gauche.premiers);
        	this.premiers.addAll(this.droit.premiers);
        	this.derniers.addAll(this.droit.derniers);
        	this.derniers.addAll(this.gauche.derniers);
        }
        else if(s=='.'){
        	this.premiers.addAll(this.gauche.premiers);
        	this.derniers.addAll(this.droit.derniers);
        	if(this.gauche.contientMotVide)this.premiers.addAll(this.droit.premiers);
        	if(this.droit.contientMotVide)this.derniers.addAll(this.gauche.derniers);
        }
	}
	
	 public Map<Feuille, Set<Feuille>> succ(){
		Map<Feuille, Set<Feuille>> succ = new HashMap<Feuille, Set<Feuille>>();
		succ.putAll(gauche.succ());
		succ.putAll(droit.succ());
			if (symbole == '.'){
				for (Feuille f : gauche.derniers) {
		            succ.get(f).addAll(droit.premiers);
		        }
			}
		return succ;
		 
	 }

	@Override
	Arbre residuel(char c) {
		if(this.symbole=='.'){
			Arbre resi = new Binaire(gauche.residuel(c),droit,'.'); // (a-1) ab -> b ou (a-1) bb
			if(gauche.contientMotVide||gauche.epsilon){ // (b-1) (ba + 1).b
				return new Binaire(resi.simpleArbre(),droit.residuel(c),'+').simpleArbre();
			}
			return resi.simpleArbre(); // (b-1) (ab + bb).b
		}
		else if(this.symbole=='+'){
			return new Binaire(gauche.residuel(c),droit.residuel(c),'+').simpleArbre();// (b-1) (bbb + ba) on doit faire le residuel des deux cotes
		}
		return new Feuille('0'); // sinon on retourne le mot vide
	}
	

	@Override
	public HashSet<String> contientArbre() {
		HashSet<String> set = new HashSet<String>();
		if(this.symbole == '+'){
			set.addAll(gauche.contientArbre());
			set.addAll(droit.contientArbre());
			return set;
		}
		set.add(this.toString());
		return set;
	}

	@Override
	Arbre simpleArbre() {
		if(this.symbole=='+'){
			if(gauche.symbole == '0' && droit.symbole == '0') return new Feuille('0');
			else if(gauche.symbole == '0')return droit.simpleArbre(); // si gauche est vide on revoi juste la simpleArbre de droit
			else if(droit.symbole == '0')return gauche.simpleArbre(); // si droit est vide on revoi juste la simpleArbre de gauche
			// si droite ou gauche est epsilon alors en renvoi l'autre en lui ajoutant le mot vide
            else if(gauche.symbole == 'Ɛ'){
				droit.epsilon =true;
				return droit.simpleArbre();
			}
			else if(droit.symbole == 'Ɛ'){
				gauche.epsilon =true;
				return gauche.simpleArbre();
			}
            // a+(a+b) = a+b
			for(String s:gauche.contientArbre()){
				if(droit.toString().matches(s))return gauche.simpleArbre();
			}
			for(String s:droit.contientArbre()){
				if(gauche.toString().matches(s))return droit.simpleArbre();
			}
		}
		else if(this.symbole=='.'){
			if(gauche.symbole == '0' || droit.symbole == '0')return new Feuille('0');
			else if(gauche.symbole == 'Ɛ') return droit.simpleArbre();
			else if(droit.symbole == 'Ɛ') return gauche.simpleArbre();

            else if(gauche.epsilon){
				gauche.epsilon =false;
                if(!gauche.contientMotVide)return new Binaire(this,droit,'+').simpleArbre();
			}
			else if(droit.epsilon){
				droit.epsilon =false;
                if(!droit.contientMotVide)return new Binaire(this,gauche,'+').simpleArbre();
			}
		}
		return this;
	}
	
}