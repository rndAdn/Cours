#ifndef XMALLOC_H
# define XMALLOC_H

# define xmalloc(T) ((T *) malloc (sizeof ( T )))

#endif /* ! XMALLOC_H */
