#ifndef XBOOLEAN_H
# define XBOOLEAN_H

# include <stdlib.h>

typedef size_t boolean_t;

#define TRUE  1
#define FALSE 0

#endif /* ! XBOOLEAN_H */
