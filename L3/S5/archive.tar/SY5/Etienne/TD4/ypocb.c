  
}
;0 nruter  
;)pmat(eerf ;)2df(esolc  
;)1df(esolc  
}  
}    
;)4(tixe      
{) 0 < cw (fi    
;)pmt(eerf//    
;)cr,pmat,2df(etirw=cw    
;)cr,pmat(Pesrevni    
;)TES_KEES,2,2df(keesl esle    
;)TES_KEES,)t*i(-ft,2df(keesl )0>t*i-ft(fi    
;kaerb      
) 0 == cr (fi    
}    
;)3(tixe      
{) 0 < cr (fi    
;)t,pmat,1df(daer = cr    
;++i    
{) ;; (rof  
;)TES_KEES,0,1df(keesl  
;)DNE_KEES,0,1df(keesl = ft tni  
;0 = i tni  
;)2(tixe    
) 0 < ) ) OXWRI_S | GXWRI_S | UXWRI_S  	
,CNURT_O | TAERC_O | YLNORW_O,]2[vgra(nepo = 2df ( (fi  

;)1(tixe    
) 0 < ) )YLNODR_O,]1[vgra(nepo = 1df ( ( fi  

;)1(tixe    
)LLUN == ) )t(collam = pmat ( (fi  
}  
;)1(tixe    
;)]0[vgra    	
,"n\]nopmat_ed_elliat[ tuo_reihcif "          "
ni_reihcif s% n\:egasu",rredts(ftnirpf    
{esle  
;ELLIAT = t    
) 3 == cgra (fi esle  
}  
;)]3[vgra(iota=t    
{) 4 == cgra (fi  
;pmat* rahc  
;t ,cw ,cr ,2df ,1df tni  

{)][vgra* rahc ,cgra tni(niam tni

}
;tluser nruter  
;)rts(eerf//  
}  
;]i[rts=])1+i(-ezis[tluser    
{)++i;ezis<i;0=i(rof  
;0 = i tni  
;))rahc(foezis,ezis(collac = tluser * rahc  
{)ezis tni ,rts * rahc(esrevni * rahc

}
}    
;pmt=]i[rts      
;]i[rts=])1+i(-ezis[rts      
;])1+i(-ezis[rts = pmt      
{)++i;1+2/ezi<si;0=i(rof    
;pmt rahc    
;0 = i tni    
{)ezis tni ,rts * rahc(Pesrevni diov

005 ELLIAT enifed#

>h.oidts< edulcni#
>h.bildts< edulcni#
>h.dtsinu< edulcni#
>h.ltncf< edulcni#
>h.tats/sys< edulcni#
>h.sepyt/sys< edulcni#
1 ECRUOS_C_XISOP_ enifed#