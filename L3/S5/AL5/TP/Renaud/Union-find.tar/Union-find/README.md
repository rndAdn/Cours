#UnionFind

Algorythme Union-Find.
Implémentation en Java et python.
