
public class Manga extends BandeDessinee{
	
	public Manga(String titre, String auteur,String illustrateur, int nbrePages) {
		super(titre, auteur, illustrateur, nbrePages);
		// TODO Auto-generated constructor stub
	}

}
