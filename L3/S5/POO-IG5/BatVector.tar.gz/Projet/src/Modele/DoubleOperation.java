package Modele;

import java.math.BigDecimal;

/**
 * Created by ByTeK on 13/11/2014.
 */
public interface DoubleOperation {
    /**
     * Fonction affine des droite.
     * @param i
     * @return
     */
    public BigDecimal operate(BigDecimal i);
}
