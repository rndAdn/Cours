package Modele;

/**
 * Created by ByTeK on 21/11/2014.
 */
public class FormeNotFoundExeption extends Exception {
    public FormeNotFoundExeption(){
        super();
    }
}
