package Modele;

/**
 * Created by ByTeK on 17/11/2014.
 */
public enum Mode {
    grab(1),
    select(2),
    point(3),
    droite(4),
    segment(5),
    cercle(6),
    poly(7),
    loupe(9),
    bezize(10);

    Mode(int i){
    }
}
