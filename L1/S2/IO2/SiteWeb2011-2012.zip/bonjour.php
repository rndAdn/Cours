<div id="index">
	<h2>BIENVENUE  SITE FERME AU PUBLIC</h2>
	<p>Ce lieux est fait pour tout amateurs de glisse, que se soit du Surf, du kitesurf, du Snowboard, bref tout ce qui se raid.<br/>
		Le but etant de mettre les meilleurs clichés qu'on a pu prendre dans ces meilleurs section, ou trip!<br>
		pour cela nous vous proposons un site où vous pourrez mettre vos photos, les commenter, les aimers.</p>
	
			<!-- script pris sur la page :
			http://webmaster.multimania.fr/tips/988878374/ -->
		
		<SCRIPT LANGUAGE="JavaScript">

				var timeDelay = 2;
				var Pix = new Array
					("/Photos/diapo/1.jpg"
					//,"/Photos/diapo/2.jpg"
					,"/Photos/diapo/3.jpg"
					,"/Photos/diapo/4.jpg"
					,"/Photos/diapo/5.jpg"
					//,"/Photos/diapo/6.jpg"
					//,"/Photos/diapo/7.jpg"
					//,"/Photos/diapo/8.jpg"
					//,"/Photos/diapo/9.jpg"
					,"/Photos/diapo/10.jpeg"
					//,"/Photos/diapo/11.jpg"
					);
					var howMany = Pix.length;
					timeDelay *= 1000;
					var PicCurrentNum = 0;
					var PicCurrent = new Image();
					PicCurrent.src = Pix[PicCurrentNum];
					function startPix() {
						setInterval("slideshow()", timeDelay);
					}
					function slideshow() {
						PicCurrentNum++;
						if (PicCurrentNum == howMany) {
							PicCurrentNum = 0;
						}
						PicCurrent.src = Pix[PicCurrentNum];
						document["ChangingPix"].src = PicCurrent.src;
					}

			</script>
			<img class="diapo" name="ChangingPix" src="/Photos/diapo/1.jpg">
			
			
			
	<?php
		if((isset($_POST['err']) && !empty($_POST['login']))){
			echo $_POST['err'];
		}
	?>
</div>