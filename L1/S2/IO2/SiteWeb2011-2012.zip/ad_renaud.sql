-- phpMyAdmin SQL Dump
-- version 3.1.5
-- http://www.phpmyadmin.net
--
-- Serveur: ad.renaud.sql.free.fr
-- Généré le : Ven 04 Mai 2012 à 17:38
-- Version du serveur: 5.0.83
-- Version de PHP: 5.3.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `ad_renaud`
--

-- --------------------------------------------------------

--
-- Structure de la table `commentaires`
--

CREATE TABLE IF NOT EXISTS `commentaires` (
  `id` int(200) NOT NULL auto_increment,
  `id_photo` int(100) NOT NULL,
  `id_user` int(120) NOT NULL,
  `commentaires` longtext character set utf8 NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=24 ;

--
-- Contenu de la table `commentaires`
--

INSERT INTO `commentaires` (`id`, `id_photo`, `id_user`, `commentaires`, `date`) VALUES
(1, 1, 2, 'nice\r\n', '2012-05-01'),
(2, 1, 2, 'so', '2012-05-01'),
(3, 0, 2, 'nice', '2012-05-01'),
(4, 1, 2, 'Commentevh,fy,', '2012-05-01'),
(5, 1, 2, 'Comme', '2012-05-01'),
(6, 0, 2, 'Comme', '2012-05-01'),
(7, 2, 2, 'C', '2012-05-01'),
(8, 2, 2, 'gg', '2012-05-01'),
(9, 3, 2, 'Commentair', '2012-05-01'),
(10, 2, 2, 'ndv', '2012-05-02'),
(11, 3, 2, 'aie', '2012-05-02'),
(12, 3, 2, 'aie', '2012-05-02'),
(13, 1, 2, 'Com\r\nuuh', '2012-05-02'),
(14, 1, 2, 'Com\r\nuuh', '2012-05-02'),
(15, 3, 2, 'lkndvb', '2012-05-02'),
(16, 3, 2, 'Commentairenhbvgr', '2012-05-02'),
(17, 3, 2, 'jcnbdbybc', '2012-05-02'),
(18, 3, 2, 'jcnbdbybc', '2012-05-02'),
(19, 3, 2, 'jcnbdbybc', '2012-05-02'),
(20, 3, 2, 'ahah', '2012-05-03'),
(21, 2, 3, 'nice', '2012-05-03'),
(22, 2, 3, 'fyjfyf', '2012-05-03'),
(23, 2, 2, 'iyiuoèyie', '2012-05-03');

-- --------------------------------------------------------

--
-- Structure de la table `membres`
--

CREATE TABLE IF NOT EXISTS `membres` (
  `id` int(11) NOT NULL auto_increment,
  `nom` varchar(15) character set utf8 NOT NULL,
  `prenom` varchar(15) character set utf8 NOT NULL,
  `login` text character set utf8 NOT NULL,
  `mail` text character set utf8 NOT NULL,
  `pwd` text NOT NULL,
  `sport` varchar(15) NOT NULL,
  `dateNaissance` date NOT NULL,
  `dateInscription` date NOT NULL,
  `dateConnexion` datetime NOT NULL,
  `avatar` varchar(250) NOT NULL default 'Avatar/avatar.gif',
  `nombresPhotos` int(10) NOT NULL default '0',
  `nombresCom` int(11) NOT NULL default '0',
  `score` int(20) NOT NULL default '10',
  `photoAimer` longtext NOT NULL,
  `amis` longtext NOT NULL,
  `notification` tinyint(4) NOT NULL,
  `admin` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Contenu de la table `membres`
--

INSERT INTO `membres` (`id`, `nom`, `prenom`, `login`, `mail`, `pwd`, `sport`, `dateNaissance`, `dateInscription`, `dateConnexion`, `avatar`, `nombresPhotos`, `nombresCom`, `score`, `photoAimer`, `amis`, `notification`, `admin`) VALUES
(1, 'Administrateur', 'Admin', 'admin', 'adequin.renaud@gmail.com', '6c5b3ff39f3a75b279ac455f20b491d6', 'surf', '1990-08-07', '2012-05-01', '0000-00-00 00:00:00', 'Avatar/avatar.gif', 0, 0, 10000, '', '', 0, 1),
(2, 'Adequin', 'Renaud', 'SLATER', 'adequin.renaud@gmail.com', '967719873a276b528f571b2a4b3025b5', 'skate', '1990-08-07', '2012-05-01', '2012-05-04 13:48:47', 'http://www.ftw-design.com/images/artwork/skater.jpg', 3, 18, 31, ',2,,3,,1,', ',3,,4,,1,', 0, 0),
(3, 'Dadon', 'Norman', 'Nono', 'adequin.renaud@gmail.com', '6c5b3ff39f3a75b279ac455f20b491d6', 'surf', '1990-08-07', '2012-05-01', '2012-05-04 09:40:46', 'Avatar/avatar.gif', 0, 2, 12, ',2,,2,,3,,1,', ',2,', 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `motsCles`
--

CREATE TABLE IF NOT EXISTS `motsCles` (
  `id` int(11) NOT NULL auto_increment,
  `id_photo` longtext collate latin1_general_ci NOT NULL,
  `motscles` longtext character set utf8 NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=12 ;

--
-- Contenu de la table `motsCles`
--

INSERT INTO `motsCles` (`id`, `id_photo`, `motscles`) VALUES
(1, ',1,', 'OLIE'),
(2, ',1,,2,', 'PLANCHE'),
(3, ',1,', 'RAMPE'),
(4, ',1,', ''),
(5, ',2,', 'SAUT'),
(6, ',2,', 'MARCHE'),
(7, ',2,', 'ESCALIERS'),
(8, ',2,', 'PRO'),
(9, ',3,', 'SLIDE'),
(10, ',3,', 'MARCHES'),
(11, ',3,', 'SKATER');

-- --------------------------------------------------------

--
-- Structure de la table `notification`
--

CREATE TABLE IF NOT EXISTS `notification` (
  `id` int(11) NOT NULL auto_increment,
  `id_user` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `id_notif` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=6 ;

--
-- Contenu de la table `notification`
--

INSERT INTO `notification` (`id`, `id_user`, `type`, `id_notif`) VALUES
(2, 1, 0, 2);

-- --------------------------------------------------------

--
-- Structure de la table `photo`
--

CREATE TABLE IF NOT EXISTS `photo` (
  `id` int(10) NOT NULL auto_increment,
  `id_user` int(10) NOT NULL,
  `nom_photo` varchar(20) character set utf8 NOT NULL,
  `url` longtext NOT NULL,
  `description` longtext character set utf8 NOT NULL,
  `sport` text character set utf8 NOT NULL,
  `plus` int(20) NOT NULL default '0',
  `priver` int(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Contenu de la table `photo`
--

INSERT INTO `photo` (`id`, `id_user`, `nom_photo`, `url`, `description`, `sport`, `plus`, `priver`) VALUES
(1, 2, 'P''ti olie', 'http://photocompetition.hispeed.ch/original/376751/skater/sport_skate_homme.jpg', 'P''ti olie a la plaine ', 'skate', 1, 0),
(2, 2, 'saut de marche', 'http://static.flickr.com/25/56382644_d17028fb53.jpg', 'saut samedi dernier sur les marche de cora ', 'skate', 0, 0),
(3, 2, 'Slidef', 'http://www.brolive.org/photo_gallery/photos-skateboarder-7/quel_est_le_trick_de_ce_skateur.jpg', 'mon premier slide', 'surf', 0, 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
