<div id="menu">
	<ul>
		<li><a href="index.php?p=bonjour"> Accueil </a></li>
		<li><a href="index.php?p=inscription">Inscription</a></li>
		<li><a href="index.php?p=connexion">Connexion</a></li>
		
	</ul>
</div>