<?php


	f5();
    //On vérifie si le champ est rempli
	if (isset($_POST['upload']) && $_POST['upload'] == 'Envoyer') {
		connect();

		$img = $_POST['avatar'];
		$id = $_SESSION['id'];
		mysql_query("UPDATE membres SET avatar ='$img' WHERE id ='$id'");
		mysql_close();

		$_SESSION['avatar'] = $img;
	}
?>
<div id="monCompte">




	<?php
		f5();
		if(isset($_POST['modifMC'])){
			echo '<form method="post" action="index.php?p=monCompte" >
				<table>
				<tr>
					<th>Nom</th>
					<td><input type="text" name="nom" value="'.$_SESSION['nom'].'" /><br/></td>
				</tr>
				<tr>
					<th>Prénom</th>
					<td><input type="text" name="prenom" value="'.$_SESSION['prenom'].'" /></td>
				</tr>

				<tr>
					<th>Pseudo</th>
					<td><input type="text" name="login" value="'.$_SESSION['login'].'"/></td>
				</tr>

				<tr>
					<th>Date de naissance</th>
					<td>Jour : <input type="date" size="1" maxlength="2" name="jour"/>  Mois : <input type="date" size="1" maxlength="2" name="mois" />  Année : <input type="date" size="4" maxlength="4" name="annee" /></td>
				</tr>
				<tr>
					<th>Mail</th>
					<td><input type="address" name="mail" value="'.$_SESSION['mail'].'"/></td>
				</tr>
				<tr>
					<th>Quel est votre sport préféré</th>
					<td><select name="sport">
								<option value="surf">Surf</option>
								<option value="winsurf">Winsurf</option>
								<option value="kitesurf">Kitesurf</option>
								<option value="wakeboard">Wakeboard</option>
								<option value="snowboard">Snowboard</option>
								<option value="skate">Skate</option>
						</select>
					</td>
				</tr>
				<tr>
					<th>Mot de passe (Si vous ne voulez pas changer de mot de passe ...)</th>
					<td><input type="pwd" name="pwd" /></td>
				</tr>

				<tr>
					<th>Confiermer mot de passe (Si vous ne voulez pas changer de mot de passe ...)</th>
					<td><input type="pwd" name="pwd2" /></td>
				</tr>
				<tr>
					<th>Avatar</th>
					<td> <input type="text" name="avatar" value="'.$_SESSION['avatar'].'"/></td>
				</tr>
				<tr>
					<td><input type="submit" name="ApplicationModif" value="Application des modifications" /></td>
				</tr>
			</table>
			<br/>
		</form>
			</form>



			';
		}
		else if (isset($_POST['ApplicationModif'])){
			$dateAmericaine = $_POST['annee']."-".$_POST['mois']."-".$_POST['jour'];
			$pwd = $_POST['pwd'];
			connect();
			$sql = 'UPDATE membres SET nom="'.mysql_escape_string($_POST['nom']).'", prenom="'.mysql_escape_string($_POST['prenom']).'", login="'.mysql_escape_string($_POST['login']).'", mail="'.mysql_escape_string($_POST['mail']).'", pwd="'.mysql_escape_string(md5($pwd)).'", dateNaissance="'.mysql_escape_string($dateAmericaine).'",sport="'.mysql_escape_string($_POST['sport']).'" WHERE id='.$id.'';//on inscrit le membre


			mysql_query($sql) or die('Erreur SQL !'.$sql.'<br />'.mysql_error());
			email($pwd);


			//mysql_query("UPDATE membres SET nom='$amiS',prenom='$amiS',login='$amiS',mail='$amiS',pwd='$amiS',sport='$amiS',avatar='$amiS',dateNaissance='$amiS'  WHERE id ='$id'");


		}
		else {
			echo'<div id="en_teteMembre"><h1>Bonjour '.$_SESSION['nom'].' "'.$_SESSION['login'].'" '.$_SESSION['prenom'].'</h1>

			Score : '.$_SESSION['score'].' Nombre de photo : '.$_SESSION['nombresPhotos'].' Nombre de commentaire : '. $_SESSION['nombresCom'].'</div>';

			echo '<div id="info"<h2>MES INFOS</h2>
			<p>
				Date de Naissance : '.$_SESSION['dateNaissance'].'<br/>
				Date d\'inscription : '.$_SESSION['dateInscrption'].'<br/>
				Dernière fois connecté le  : '.$_SESSION['dateConnexion'].'<br/><br/>
				Adresse Mail : '.$_SESSION['mail'].'<br/>
				Votre sport préféré est le  : '.$_SESSION['sport'].'<br/>

			</p></div>';


			echo '
			<form method="post" action="index.php?p=monCompte" >
				<input type="submit" name="modifMC" value="Modifier" />
			</form>
			';
		}
	?>

 </div>
