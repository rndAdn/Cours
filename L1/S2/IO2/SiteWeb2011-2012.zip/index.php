<?php
session_start();
?>
<!DOCTYPE html>
<html lang="fr">
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" href="style1.css" />
		<title>c2c</title>
	</head>
	<body OnLoad="startPix()">
		<header>
			<?php
				include ('function.php');
				if(isset($_SESSION['login']) && !empty($_SESSION['login'])){ //si il est connecté
					if($_SESSION['admin'] == 1){ // si il est admin
						include ('menu_admin.php');
					}
					else{ //sinon
						include ('menu_membre.php');
					}
				}
				else {
					include ('menu.php');
				}
			?>
		</header>
		<article>

			<?php
				if((isset($_SESSION['err']) && !empty($_SESSION['err']))){
				echo $_SESSION['err'];
				}
			?>

			<?php
				if(isset($_GET['p']) && preg_match("/^[a-z0-9]+$/i",$_GET['p'])){
					//$p=strtolower($_GET['p']);
					$p=$_GET['p'];
					if(file_exists("$p.php")){
						include "$p.php";
					}
				}
				else {

					include "bonjour.php";
				}


			?>
		</article>

		<footer>
			<p>
				Site réalisé par Adequin Renaud et Quiroz Andres dans le cadre d'un projet pour le cours Internet &amp;
				Outil. En Licence 1 Ã  l'Université Paris 7 Diderot.<br/>
				<a href="index.php?p=apropos">&Aacute; propos du Projet/Site</a>
			</p>
			
			<!-- www.webtutoriaux.com Compteur de visiteurs -->
<script type='text/javascript' src='http://www.webtutoriaux.com/services/compteur-visiteurs/index.php?client=123250'></script>
<!-- End Compteur de visiteurs -->
		</footer>
	</body>
</html>
