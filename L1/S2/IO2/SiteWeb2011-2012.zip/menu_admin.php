<?php
	if(!(isset($_SESSION['login']) && !empty($_SESSION['login'])) && !($_SESSION['admin'] == 1)){ // RAJOUTER SI ON N'EST PAS ADMIN ON Degage
			$_SESSION['err'] = "vous n'est pas connecté ou pas administrateur";
			print("<script type=\"text/javascript\">setTimeout('location=(\"index.php\")' ,1);</script>");
	}
?>
<div id="menu">	
	<div id="menu2">
		<ul>
			<li><a href="index.php?p=bonjour"> Liste des membres </a></li>
			<li><a href="index.php?p=inscription">Les Photos </a></li>
			<li><a href="index.php?p=deconnexion">DÃ©connexion</a></li>
			<li><form method="post" action="index.php?p=recherche" ><input type="texte" name="recherche" /></li>
			<li><input type="submit" value="Rechercher" /></form></li>
		</ul>
	</div>
</div>