<?php
	function  verifInscrption() {

		if(!(isset($_POST['login']) && !empty($_POST['login']))){
			return false;
		}
		else if(!(isset($_POST['jour']) && !empty($_POST['jour']))){
			return false;
		}
		else if(!(isset($_POST['mois']) && !empty($_POST['mois']))){
			return false;
		}
		else if(!(isset($_POST['annee']) && !empty($_POST['annee']))){
			return false;
		}
		else if(!(isset($_POST['mail']) && !empty($_POST['mail']))){
			return false;
		}
		else if(!(isset($_POST['mail2']) && !empty($_POST['mail2']))){
			return false;
		}
		else if($_POST['mail2'] != $_POST['mail']){
			return false;
		}

		return true;
	}

	function  verifLogin() {

		// on recherche si ce login est dÃ©jÃ  utilisÃ© par un autre membre
       	$sql = 'SELECT count(*) FROM membres WHERE login="'.mysql_escape_string($_POST['login']).'"';
       	$req = mysql_query($sql);
       	$data = mysql_fetch_array($req);

       	return ($data[0] == 0);

	}
	/*
	 * Le si a été mise en ligne pour pouvoir utilisé le service mail*/
	function email($mdp){
		$destinataire = $_POST['mail'];
		$expediteur   = "admin@mon_site.com";
		$reponse      = $expediteur;
		mail($destinataire,
			"inscription au site C2C",
			'Bienvenue '.$_POST['login'].' sur le site du Projet D\'IO2 voici ton mot de passe : '.$mdp,
			'From: '.$expediteur);
	}

	// fonction trouvé sur http://www.phpascal.com/programmation-web/PHP/creation-mot-de-passe.html
	function motDePasse(){
        $mot_de_passe = "";

        $chaine = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        $longeur_chaine = strlen($chaine);

        for($i = 1; $i <= 8; $i++)
        {
            $place_aleatoire = mt_rand(0,($longeur_chaine-1));
            $mot_de_passe .= $chaine[$place_aleatoire];
        }

        return $mot_de_passe;
}

	function connect(){
		$base = mysql_connect ('sql.free.fr', 'ad.renaud', 'bebey95');
		mysql_select_db ('ad.renaud', $base) ;
		mysql_query("SET NAMES 'utf8'");
	}

	function redirection($addresse){//a remplacer par meta
		print("<script type=\"text/javascript\">setTimeout('location=(\"index.php?p=$addresse\")' ,1);</script>");
	}

	/* a faire fonction :
			date americaine/francaise

	*/
	function f5(){
		connect();
		$id = $_SESSION['id'];
		$reponse = mysql_query("SELECT * FROM membres WHERE id='$id'"); // on verifi si le membre et le mot de passe existe
		$donnees = mysql_fetch_array($reponse);//on crÃ©Ã© un petit tableau des rÃ©sultats (normalement, il y en a qu'un si t'as tout bien configurÃ© lors de l'inscription)
		$_SESSION['nom'] = $donnees['nom'];
		$_SESSION['mail'] = $donnees['mail'];// Session contenant l'e-mail du membre
		$_SESSION['amis'] = $donnees['amis'];
		$_SESSION['login'] = $donnees['login']; // Session contenant le login du membre
		$_SESSION['score'] = $donnees['score'];
		$_SESSION['sport'] = $donnees['sport'];
		$_SESSION['admin'] = $donnees['admin'];
		$_SESSION['prenom'] = $donnees['prenom'];
		$_SESSION['avatar'] = $donnees['avatar'];
		$_SESSION['nombresCom'] = $donnees['nombresCom'];
		$_SESSION['nombresPhotos'] = $donnees['nombresPhotos'];
		$_SESSION['dateNaissance'] = $donnees['dateNaissance'];
		$_SESSION['dateConnexion'] = $donnees['dateConnexion'];
		$_SESSION['dateInscrption'] = $donnees['dateInscription'];
		mysql_close();
		// redirection("monCompte");



	}

	function tabTTPhoto(){
		connect();
		$id = $_SESSION['id'];
		$sql = "SELECT * FROM photo WHERE id_user='$id'"; // on cherche dans la BDD les photo du membre
		$query = mysql_query($sql) or die ("RequÃªte incorrecte"); // resultat de la recherche
		$result = mysql_numrows($query); // nombre de rÃ©sultat

		$tabPhoto=array(); // tableau (2D) qui contiendra les photo du membre





		if ($result > 0) { //si on a des rÃ©sultats "$result est > 0"
			/*
				Dans le tableau $tabPhoto[][]
				le 1er [] est le numÃ©ro de la photo une ligne par photo
			*/
			$i=0; // NÂ° de la ligne de notre tableau
			while ($row = mysql_fetch_array($query)) { //tant que qu'il rest des  resultat non traitÃ©
				$j=0; //colone de notre tableau
				$tabPhoto[$i][$j] = $row["id"]; //colone 0 le numÃ©ro de la photo dans la BDD
				$j++;
				$tabPhoto[$i][$j] = $row["url"];  //colone 1 l'url de la photo dans la BDD
				$j++;
				$tabPhoto[$i][$j] = $row["nom_photo"];  //colone 2 le nom de la photo dans la BDD
				$j++;
				$tabPhoto[$i][$j] = $row["description"]; //colone 3 la description de la photo dans la BDD
				$j++;
				$tabPhoto[$i][$j] = $row["plus"];  //colone 4 le score de la photo dans la BDD
				$j++;
				$tabPhoto[$i][$j] = $row["priver"];  //colone 5 1 si la photo est privÃ© dans la BDD
				$j++;

				$tabPhoto[$i][$j] = $row["id_user"];  //colone 6 1 si la photo est privÃ© dans la BDD
				$j++;

				$i++;
			}
			$_SESSION['toutesPhoto'] = $tabPhoto;
		}
	}

	//DERNIERES PHOTO 4

	//"SELECT date, title, displayed FROM " . DB_TABLE_NEWS . " ORDER BY date DESC";
	function tabDerPhoto(){
		connect();
		$id = $_SESSION['id'];
		$sql = "SELECT * FROM photo WHERE id_user='$id' ORDER BY id DESC LIMIT 0,4"; // on cherche dans la BDD les photo du membre
		$query = mysql_query($sql) or die ("RequÃªte incorrecte"); // resultat de la recherche
		$result = mysql_numrows($query); // nombre de rÃ©sultat


		$tabPhoto=array(); // tableau (2D) qui contiendra les photo du membre





		if ($result > 0) { //si on a des rÃ©sultats "$result est > 0"
			/*
				Dans le tableau $tabPhoto[][]
				le 1er [] est le numÃ©ro de la photo une ligne par photo
			*/
			$i=0; // NÂ° de la ligne de notre tableau
			while ($row = mysql_fetch_array($query)) { //tant que qu'il rest des  resultat non traitÃ©
				$j=0; //colone de notre tableau
				$tabPhoto[$i][$j] = $row["id"]; //colone 0 le numÃ©ro de la photo dans la BDD
				$j++;
				$tabPhoto[$i][$j] = $row["url"];  //colone 1 l'url de la photo dans la BDD
				$j++;
				$tabPhoto[$i][$j] = $row["nom_photo"];  //colone 2 le nom de la photo dans la BDD
				$j++;
				$tabPhoto[$i][$j] = $row["description"]; //colone 3 la description de la photo dans la BDD
				$j++;
				$tabPhoto[$i][$j] = $row["plus"];  //colone 4 le score de la photo dans la BDD
				$j++;
				$tabPhoto[$i][$j] = $row["priver"];  //colone 5 1 si la photo est privÃ© dans la BDD
				$j++;

				$tabPhoto[$i][$j] = $row["id_user"];  //colone 6 1 si la photo est privÃ© dans la BDD
				$j++;

				$i++;
			}
			$_SESSION['dernierePhoto'] = $tabPhoto;
		}
	}

	// Les plus aimÃ©es
	//"SELECT date, title, displayed FROM " . DB_TABLE_NEWS . " ORDER BY date DESC";
	function tabMPhoto(){
		connect();
		$id = $_SESSION['id'];
		$sql = "SELECT * FROM photo WHERE id_user='$id' ORDER BY plus DESC LIMIT 0,4"; // on cherche dans la BDD les photo du membre
		$query = mysql_query($sql) or die ("RequÃªte incorrecte"); // resultat de la recherche
		$result = mysql_numrows($query); // nombre de rÃ©sultat


		$tabPhoto=array(); // tableau (2D) qui contiendra les photo du membre





		if ($result > 0) { //si on a des rÃ©sultats "$result est > 0"
			/*
				Dans le tableau $tabPhoto[][]
				le 1er [] est le numÃ©ro de la photo une ligne par photo
			*/

			$i=0; // NÂ° de la ligne de notre tableau
			while ($row = mysql_fetch_array($query)) { //tant que qu'il rest des  resultat non traitÃ©
				$j=0; //colone de notre tableau
				$tabPhoto[$i][$j] = $row["id"]; //colone 0 le numÃ©ro de la photo dans la BDD
				$j++;
				$tabPhoto[$i][$j] = $row["url"];  //colone 1 l'url de la photo dans la BDD
				$j++;
				$tabPhoto[$i][$j] = $row["nom_photo"];  //colone 2 le nom de la photo dans la BDD
				$j++;
				$tabPhoto[$i][$j] = $row["description"]; //colone 3 la description de la photo dans la BDD
				$j++;
				$tabPhoto[$i][$j] = $row["plus"];  //colone 4 le score de la photo dans la BDD
				$j++;
				$tabPhoto[$i][$j] = $row["priver"];  //colone 5 1 si la photo est privÃ© dans la BDD
				$j++;

				$tabPhoto[$i][$j] = $row["id_user"];  //colone 6 1 si la photo est privÃ© dans la BDD
				$j++;

				$i++;
			}
			$_SESSION['MPhoto'] = $tabPhoto;
		}
	}

	function tabLikePhoto(){
		//recuperer les id des photo aimées
		$id = $_SESSION['id'];
		$reqIdPhotoAimer = "SELECT photoAimer FROM membres WHERE id='$id'";
		$query = mysql_query($reqIdPhotoAimer) or die ("Requète incorrecte"); // resultat de la recherche

		//metttre les id des photos dans un tableau
		$tabPhoto = array();
		$result = mysql_numrows($query); // nombre de rÃ©sultat
		$row = mysql_fetch_array($query);
		$photo = explode(",",$row["photoAimer"]);
		if ($result > 0) { //si on a des rÃ©sultats "$result est > 0"
			/*
				Dans le tableau $tabPhoto[][]
				le 1er [] est le numÃ©ro de la photo une ligne par photo
			*/
			$k =0;
			for($i = 0 ; $i<sizeof($photo); $i++){
				if($photo[$i] != "" && $photo[$i] != " " && $photo[$i] != ","){
						$tabPhoto[$k][0] = $photo[$i];
						$k++;
					}
			}

		}


		//recuperer les photo aimées
		for($i = 0 ; $i<sizeof($tabPhoto); $i++){
			$id = $tabPhoto[$i][0];
			$sql = "SELECT * FROM photo WHERE id='$id' ORDER BY plus DESC LIMIT 0,4"; // on cherche dans la BDD les photo du membre
			$query = mysql_query($sql) or die ("RequÃªte incorrecte"); // resultat de la recherche
			$result = mysql_numrows($query); // nombre de rÃ©sultat

			if ($result > 0) { //si on a des rÃ©sultats "$result est > 0"
			/*
				Dans le tableau $tabPhoto[][]
				le 1er [] est le numÃ©ro de la photo une ligne par photo
			*/
				$row = mysql_fetch_array($query);

				$tabPhoto[$i][1] = $row["url"];  //colone 1 l'url de la photo dans la BDD
				$tabPhoto[$i][2] = $row["nom_photo"];  //colone 2 le nom de la photo dans la BDD
				$tabPhoto[$i][3] = $row["description"]; //colone 3 la description de la photo dans la BDD
				$tabPhoto[$i][4] = $row["plus"];  //colone 4 le score de la photo dans la BDD
				$tabPhoto[$i][5] = $row["priver"];  //colone 5 1 si la photo est privÃ© dans la BDD
				$tabPhoto[$i][6] = $row["id_user"];  //colone 6 1 si la photo est privÃ© dans la BDD
			}
		}
		//metttre les photos dans un tableau
		$_SESSION['LikePhoto'] = $tabPhoto;
	}

	function tabRecherchePhoto($tab){
		connect();
		$tabPhoto=array(); // tableau (2D) qui contiendra les photo du membre
		$score = $_SESSION['score'];
		for ($i = 0; $i < sizeof($tab); $i++) {

			$id = $tab[$i];
			$sql = "SELECT * FROM photo WHERE id='$id' LIMIT 0,$score"; // on cherche dans la BDD les photo du membre
			$query = mysql_query($sql) or die ("Requète incorrecte"); // resultat de la recherche
			$result = mysql_fetch_array($query); // nombre de rÃ©sultat
			$tabPhoto[$i][0] = $result['id'];
			$tabPhoto[$i][1] = $result['url'];
			$tabPhoto[$i][2] = $result['nom_photo'];
			$tabPhoto[$i][3] = $result['description'];
			$tabPhoto[$i][4] = $result['plus'];
			$tabPhoto[$i][4] = $result['priver'];
			$tabPhoto[$i][6] = $result['id_user'];

		}

		$tabAmis = $_SESSION['autreAmis'];
		$new = array();
		$k = 0;
		for($i =0 ; $i<sizeof($tabPhoto); $i++){
			if($tabPhoto[$i][4] == 1){
				$yes = false;
				for($j = 0; $j<sizeof($tabAmis); $j++){
					if($tabPhoto[$i][6] == $tabAmis[$j] ){
						$yes = true;
					}
				}
				if($yes || $tabPhoto[$i][6] == $_SESSION['id']){
					$new[$k] = $tabPhoto[$i];
					$k++;
				}
			}
			else{
				$new[$k] = $tabPhoto[$i];
				$k++;
			}

		}


		$_SESSION['recherchePhoto'] = $new;

	}


	function tabRechercheMembre($tab){
		connect();
		$tabMembre=array(); // tableau (2D) qui contiendra les photo du membre
		$j = 0;
		$score = $_SESSION['score'];
		for ($i = 0; $i < sizeof($tab); $i++) {
			$nom = $tab[$i];
			$sql = "SELECT * FROM membres WHERE nom LIKE '%$nom%' OR prenom LIKE '%$nom%' OR login LIKE '%$nom%' LIMIT 0,$score"; // on cherche dans la BDD les photo du membre
			$query = mysql_query($sql) or die ("Requuyfte incorrecte"); // resultat de la recherche
			$result = mysql_numrows($query); // nombre de rÃ©sultat

			if ($result > 0) { //si on a des rÃ©sultats "$result est > 0"
				/*
					Dans le tableau $tabPhoto[][]
					le 1er [] est le numÃ©ro de la photo une ligne par photo
				*/

				//$k=0; // NÂ° de la ligne de notre tableau
				while ($row = mysql_fetch_array($query)) { //tant que qu'il rest des  resultat non traitÃ©
					$k=0; //colone de notre tableau
					$tabMembre[$j][$k] = $row["id"]; //colone 0 le numÃ©ro de la photo dans la BDD
					$k++;
					$tabMembre[$j][$k] = $row["mon"];  //colone 1 l'url de la photo dans la BDD
					$k++;
					$tabMembre[$j][$k] = $row["prenom"];  //colone 2 le nom de la photo dans la BDD
					$k++;
					$tabMembre[$j][$k] = $row["login"]; //colone 3 la description de la photo dans la BDD
					$k++;
					$tabMembre[$j][$k] = $row["avatar"];  //colone 4 le score de la photo dans la BDD
					$k++;

					$j++;
				}

			}
		}
		$_SESSION['rechercheMembre'] = $tabMembre;



	}

	function affichageMembre($tab){
		echo '<table>';
		for($i = 0 ; $i<sizeof($tab); $i++){
			echo '<tr>';
			echo '<td><img class="mini" src="'.$tab[$i][4].'"></td><td>'.$tab[$i][3].'</td>';
			echo '</tr>';
		}
		echo '</table>';
	}




	//affichage photo carrÃ© 4

	function affichage4($tabPhoto, $class, $nom, $album){

			//print_r($tabPhoto);
			if(sizeof($tabPhoto) != 0){
			// le tableau des photo est mis dans un variable de SESSION
				$size = sizeof($tabPhoto); // taille de notre tableau
				echo "<table id=\"tab4\">";
				$i=0;
				while($i<$size){
					echo"<tr>";
					for($j=$i; $j<$i+2; $j++){// boucle pour afficher les photo du membre
						echo '<th><a href="index.php?p=photoG&album='.$album.'&photo='.$j.'">'.$tabPhoto[$j][2].'</a></th>'; //on affiche le nom de la photo
					}
					echo"</tr>";
					echo"<tr>";
					for($j=$i; $j<$i+2; $j++){// boucle pour afficher le statut privÃ©/public de la photo
						if($tabPhoto[$j][5] == 1){
							echo "<td>privé</td>"; // on affiche la privÃ© si la photo est privÃ©
						}
					}
					echo"</tr>";

					echo"<tr>";
					for($j=$i; $j<$i+2; $j++){// boucle pour afficher les photo du membre
						echo "<td><a href=\"index.php?p=photoG&album=".$album."&photo=".$j."\"><img class=\"".$class."\" src=\"".$tabPhoto[$j][1]."\"></a></td>"; // on affiche la photo, clicable + un get du nÂ° de la photo dans le tableau
					}
					echo"</tr>";
					echo"<tr>";
					for($j=$i; $j<$i+2; $j++){// boucle pour afficher les photo du membre
						echo "<th><a href=\"index.php?p=photoG&album=".$album."&photo=".$j."\">score : ".$tabPhoto[$j][4]."</a></th>"; //on affiche le nom de la photo
					}
					echo"</tr>";
					$i+=2;


				}

				echo "</table>";
			}
			else { // si on a pas de photo
				echo "Pas de résultat";
			}

	}

	/*Fonction volÃ©e sur le site : http://schizophrenie.unblog.fr/scripts-php/#3*/
	function uc_strtoupper_fr($chaine){
		$chaine=strtoupper($chaine);
		$chaine=utf8_decode($chaine);
		$chaine=trim($chaine);
		$chaine =strtr($chaine, "Ã¤Ã¢Ã Ã¡Ã¥Ã£Ã©Ã¨Ã«ÃªÃ²Ã³Ã´ÃµÃ¶Ã¸Ã¬Ã­Ã®Ã¯Ã¹ÃºÃ»Ã¼Ã½Ã±Ã§Ã¾Ã¿Ã¦Å“Ã°Ã¸ ", "Ã„Ã‚Ã€Ã�Ã…ÃƒÃ‰ÃˆÃ‹ÃŠÃ’Ã“Ã”Ã•Ã–Ã˜ÃŒÃ�ÃŽÃ�Ã™ÃšÃ›ÃœÃ�Ã‘Ã‡ÃžÃ�Ã†Å’Ã�Ã˜ ");
		$chaine=utf8_encode($chaine);
		return $chaine;
	}

	function affichageGrandePhoto($photo,$tab, $album){
		//afficher le titre au milieu
		echo '<div class="titrePhoto"><h1>'.$tab[$photo][2].'</h1></div>';


		//afficher la photo
		echo '<img class="photoAgrandi" src="'.$tab[$photo][1].'">';


		//afficher les tags


		//afficher la description
		echo '<div class="description"><strong>Description</strong> :<br/><blockquote>'.$tab[$photo][3].'</blockquote></div>';


		//afficher les fleches de navigation
		echo '<div id="arrow">';
		if($photo<=0){
			echo '<img  src="/Images/no-left.png">';
		}
		else{
			echo '<a href="index.php?p=photoG&album='.$album.'&photo='.($photo-1).'"><img  src="/Images/left.png"></a>';
		}
		if($photo >= (sizeof($tab)-1)){
			echo '<img  src="/Images/no-right.png">';
		}
		else{
			echo '<a href="index.php?p=photoG&album='.$album.'&photo='.($photo+1).'"><img  src="/Images/right.png"></a>';
		}
		echo '</div>';


		//afficher +1/-1 Score
		//affichagePlus($id_photo);
		echo '<div class="score"><h2>score : '.$tab[$photo][4].'</h2></div>';

		//afficher les commentaire
		affichageCommentaires($tab[$photo][0]);
	}

	function affichageCommentaires($id_photo){
		//requete pour avoir les comms de la photo
		connect();
		$reqcomm = "SELECT * FROM commentaires WHERE id_photo='$id_photo'";
		$query = mysql_query($reqcomm) or die ("Requète incorrecte"); // resultat de la recherche
		$result = mysql_numrows($query); // nombre de rÃ©sultat


		// conversion dans un beau tableau
		$tabCom = array();
		if ($result > 0) { //si on a des rÃ©sultats "$result est > 0"
			/*
			 Dans le tableau $tabPhoto[][]
			le 1er [] est le numÃ©ro de la photo une ligne par photo
			*/

			$j=0; // NÂ° de la ligne de notre tableau
			while ($row = mysql_fetch_array($query)) { //tant que qu'il rest des  resultat non traitÃ©
				$k=0; //colone de notre tableau
				$tabCom[$j][$k] = $row["id"]; //colone 0 le numÃ©ro de la photo dans la BDD
				$k++;
				$tabCom[$j][$k] = $row["id_user"];  //colone 1 l'url de la photo dans la BDD
				$k++;
				$tabCom[$j][$k] = $row["id_photo"];  //colone 2 le nom de la photo dans la BDD
				$k++;
				$tabCom[$j][$k]  = $row["commentaires"]; //colone 3 la description de la photo dans la BDD
				$k++;
				$tabCom[$j][$k]  = $row["date"];  //colone 4 le score de la photo dans la BDD
				$k++;

				$j++;
			}

		}



		//conversion de l'id user en login
		for($i=0; $i<sizeof($tabCom);$i++){
			$id_user = $tabCom[$i][1];
			$reqLogin = "SELECT login FROM membres WHERE id='$id_user'";
			$query = mysql_query($reqLogin) or die ("Requète incorrecte"); // resultat de la recherche
			$tab = mysql_fetch_array($query);
			$tabCom[$i][1]  = $tab['login'];

		}

		//boucle FOR
		$css = "";
		for($i=0; $i<sizeof($tabCom);$i++){
			if ($i % 2 == 0){
				$css = "comm0";
			}
			else{
				$css = "comm1";
			}
			//affichage de l'user
			echo '<div class="'.$css.'"><a href="index.php?p=pageMembre&page='.$tabCom[$i][1].'">'.$tabCom[$i][1].'</a>';



			//affichage de la date
			echo '      '.$tabCom[$i][4];

			//affichage du comm
			echo '<br/>'.$tabCom[$i][3].'</div>';
		}
	}

	function posterCommentaire($id_photo,$album,$num_photo,$tab){
		if(isset($_POST['com'])){
			$date = date('Y-m-d');
			$id = $_SESSION['id'];
			$com = $_POST['commentaire'];
			connect();
			$sq = "INSERT INTO commentaires(commentaires,id_user,id_photo, date) VALUES('$com','$id','$id_photo','$date')"; // on met la photo dans la BDD
			mysql_query($sq) or die('Erreur SQL !'.$sq.'<br />'.mysql_error()); //s'il y a une erreur
			//affichageGrandePhoto($num_photo,$tabPhoto, $album);
			//MAJ DES SCORE
			$score = $_SESSION['score'] + 1;
			$nbCom = $_SESSION['nombresCom'] + 1;

			mysql_query("UPDATE membres SET score='$score' , nombresCom='$nbCom' WHERE id ='$id'"); // on met a jour les scores du membre
			//notification
			$idM = $tab[$num_photo][6];


			mysql_query("UPDATE membres SET notification='1' WHERE id='$idM' ") or die (mysql_error());
			$sq = "INSERT INTO notification(id_user,type,id_notif) VALUES('$idM','1','$id_photo')"; // on met la photo dans la BDD
			mysql_query($sq) or die('Erreur SQL !'.$sq.'<br />'.mysql_error()); //s'il y a une erreur
		}
		else{

			echo'
			<form method="post" action="index.php?p=photoG&album='.$album.'&photo='.$num_photo.'">
			<textarea rows="4" cols="50" name="commentaire">Commentaire</textarea> <br/>
			<input type="submit" name="com" value="Commenter" />
			</form>';
		}

	}

	function plus($id_photo,$album,$num_photo,$tab){
		if(isset($_POST['plus'])){
			$id = $_SESSION['id'];
			mysql_query("UPDATE membres SET photoAimer =CONCAT(photoAimer, ',$id_photo,') WHERE id='$id'") or die('Erreur SQL !<br />'.mysql_error()); //s'il y a une erreur
			$tab[$num_photo][4]++;
			$plus=	$tab[$num_photo][4];
			$id_photo = $tab[$num_photo][4];
			mysql_query("UPDATE photo SET plus ='$plus' WHERE id='$id_photo'") or die('Erreur SQL !<br />'.mysql_error()); //s'il y a une erreur
		}
		tabLikePhoto();
		$tab = $_SESSION['LikePhoto'];
		$bool = false;
		for($i = 0; $i<sizeof($tab);$i++){
			if($tab[$i][0] == $id_photo){
				$bool = TRUE;
			}
		}
		if(!$bool){
			echo'
			<form method="post" action="index.php?p=photoG&album='.$album.'&photo='.$num_photo.'">
			<input type="submit" name="plus" value="." id="valider" class="submit" />
			</form>';
		}

	}

	function majNotificationCom(){
		$id = $_SESSION['id'];
		$reqCom  = "SELECT * FROM notification WHERE id_user='$id' AND type='1'";
		$query = mysql_query($reqCom) or die ("Requète incorrecte"); // resultat de la recherche
		$result = mysql_numrows($query); // nombre de rÃ©sultat


		// conversion dans un beau tableau
		$tabCom = array();
		if ($result > 0) { //si on a des rÃ©sultats "$result est > 0"
			/*
			 Dans le tableau $tabPhoto[][]
			le 1er [] est le numÃ©ro de la photo une ligne par photo
			*/

			$j=0; // NÂ° de la ligne de notre tableau
			while ($row = mysql_fetch_array($query)) { //tant que qu'il rest des  resultat non traitÃ©
				$k = 0;
				$tabCom[$j][$k] = $row["id"];
				$k++;
				$tabCom[$j][$k] = $row["id_notif"]; //colone 0 le numÃ©ro de la photo dans la BDD
				$j++;
			}
			$_SESSION['notifCom'] = $tabCom;

		}
		else{
			$_SESSION['notifCom'] = NULL;
		}

	}

	function majNotificationAmis(){
		$id = $_SESSION['id'];
		$reqAmis  = "SELECT * FROM notification WHERE id_user='$id' AND type='0'";
		$query = mysql_query($reqAmis) or die ("Requète incorrecte"); // resultat de la recherche
		$result = mysql_numrows($query); // nombre de rÃ©sultat


		// conversion dans un beau tableau
		$tabAmis = array();
		if ($result > 0) { //si on a des rÃ©sultats "$result est > 0"
			/*
			 Dans le tableau $tabPhoto[][]
			le 1er [] est le numÃ©ro de la photo une ligne par photo
			*/

			$j=0; // NÂ° de la ligne de notre tableau
			while ($row = mysql_fetch_array($query)) { //tant que qu'il rest des  resultat non traitÃ©
				$k = 0;
				$tabAmis[$j][$k] = $row["id"];
				$k++; //colone 0 le numÃ©ro de la photo dans la BDD
				$tabAmis[$j][$k] = $row["id_notif"];
				$j++;
			}
			$_SESSION['notifAmis'] = $tabAmis;

		}
		else{
			$_SESSION['notifAmis'] = NULL;
		}
	}

	function notification(){
		majNotificationAmis();
		majNotificationCom();
		$id = $_SESSION['id'];

		if($_SESSION['notifAmis'] == NULL && $_SESSION['notifCom'] == NULL){
			mysql_query("UPDATE membres SET notification='0' WHERE id='$id' ");
		}
		else{
			mysql_query("UPDATE membres SET notification='1' WHERE id='$id' ");
		}
	}

	//http://j-reaux.developpez.com/tutoriel/php/affichage-donnees-tableau-html/#LII-A

?>
