<div id="apropos">

	<h1>Après présentation du projet devant le jury la note du projet est de 19/20</h1>
	<h1>MAJ : 07 août 2012 site en cours de ré-écriture</h1>
	<h1>À Propos du  site</h1>
	<p>Ce site est le un projet que nous avons réalisé pour le cours d'IO2 à l'université Paris VII Diderot. <br/>Une fois notre note obtenu il n'y aura plus aucun suivi du site </p>
	<h1>Fonctionnement du site</h1>
	<h2>Amis</h2>
	<p>sur ce site quand vous ajouter une personne à votre liste d'amis elle peut voir vos photos "Privées" mais pour vois ses photos privées vous devez être dans sa liste d'amis</p>
	<h2>Photos</h2>
	<p>ce site n'hébege que les url des photos donc vos photos doivent déjà être en ligne.</p>
	<h2>Mots Clés</h2>
	<p>Les mots clés ne peuvent pas encore être modifiés</p>
	<h2>Les recherches</h2>
	<p>la recherche des photos est en fonction de votre score le nombre de resultat sera egal ou inferieur a votre score.<br/></p>
</div>
