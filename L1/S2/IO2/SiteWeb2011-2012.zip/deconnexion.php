<?php
		session_destroy();
		print("<script type=\"text/javascript\">setTimeout('location=(\"index.php\")' ,1);</script>");
?>
		
