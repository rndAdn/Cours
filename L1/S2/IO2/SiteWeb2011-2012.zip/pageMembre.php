<div>
	<?php
		connect();
		mysql_query("SET NAMES 'utf8'");

		$loginM = $_GET['page'];
		$reponse = mysql_query("SELECT * FROM membres WHERE login='$loginM'"); // on verifi si le membre et le mot de passe existe
		$donnees = mysql_fetch_array($reponse);//on créé un petit tableau des résultats (normalement, il y en a qu'un si t'as tout bien configuré lors de l'inscription)

		$tabInfo = array();
		$tabInfo['id'] = $donnees['id'];
		if($tabInfo['id'] == $_SESSION['id']){
			redirection("monCompte");
		}
		for($i = 0 ;$i <sizeof($_SESSION['notifAmis']);$i++ ){
			if($_SESSION['notifAmis'][$i][1] == $tabInfo['id'] ){
				$id_notif = $_SESSION['notifAmis'][$i][0];
				mysql_query("DELETE FROM notification WHERE id = '$id_notif'");
			}
		}
		$tabInfo['nom'] = $donnees['nom'];
		$tabInfo['prenom'] = $donnees['prenom'];
		$tabInfo['login'] = $donnees['login'];
		$tabInfo['dateNaissance'] = $donnees['dateNaissance'];
		$tabInfo['dateInscription'] = $donnees['dateInscription'];
		$tabInfo['avatar'] = $donnees['avatar'];
		$tabInfo['nombresPhotos'] = $donnees['nombresPhotos'];
		$tabInfo['nombresCom'] = $donnees['nombresCom'];
		$tabInfo['score'] = $donnees['score'];
		$tabInfo['mail'] = $donnees['mail'];
		$tabInfo['dateConnexion'] = $donnees['dateConnexion'];
		notification();

		echo '<div id="en_teteMembre">';
		echo "<img class=\"mini\" src=\"".$tabInfo['avatar']."\">";
		echo $tabInfo['nom'].' "'.$tabInfo['login'].'" '.$tabInfo['prenom'];
		echo '<br/>Score : '.$tabInfo['score'];
		echo '</div>';
		echo '<h2>INFO MEMBRE :</h2><br/>';
		echo 'Date de naissance'.$tabInfo['dateNaissance'];
		echo '<br/>cet utilisateur a post�(s) : '.$tabInfo['nombresPhotos'].' photo(s)   et '.$tabInfo['nombresCom'].' Commentaire<br/>';
		echo 'Membre depuis : '.$tabInfo['dateInscription'];


		$idM =$tabInfo['id'];

		$id = $_SESSION['id'];
		$votreAmi = "SELECT * FROM membres WHERE id='$id' AND amis LIKE '%,$idM,%'"; // on cherche dans la BDD les photo du membre
		$qu = mysql_query($votreAmi) or die ("Requ�te incorrecte"); // resultat de la recherche
		$tt = mysql_fetch_array($qu);
		$r = mysql_numrows($qu); // nombre de résultat

		$sonAmi = "SELECT * FROM membres WHERE id='$idM' AND amis LIKE '%,$id,%'"; // on cherche dans la BDD les photo du membre
		$que = mysql_query($sonAmi) or die ("Requête incorrecte"); // resultat de la recherche
		$tr = mysql_fetch_array($que);
		$re = mysql_numrows($que); // nombre de résultat

		if($re != 1){

			echo $tabInfo['login']." vous ne fait pas partie de sa liste d'amis (vous ne pouvez pas voir ses photo privé) <br/>";

			$tabPhoto=array(); // tableau (2D) qui contiendra les photo du membre
			$sql = "SELECT * FROM photo WHERE id_user='$idM' AND priver='0'"; // on cherche dans la BDD les photo du membre
			$query = mysql_query($sql) or die ("Requête incorrecte"); // resultat de la recherche
			$result = mysql_numrows($query); // nombre de résultat

		}
		else {
			echo '<br/>Deni�re fois connect� le : '.$tabInfo['dateConnexion'];
			echo '<br/>Adresse Mail : '.$tabInfo['mail'];

			echo "<br/>Vous etes son ami  <br/>";
			$tabPhoto=array(); // tableau (2D) qui contiendra les photo du membre
			$sql = "SELECT * FROM photo WHERE id_user='$idM'"; // on cherche dans la BDD les photo du membre
			$query = mysql_query($sql) or die ("Requête incorrecte"); // resultat de la recherche
			$result = mysql_numrows($query); // nombre de résultat

		}
		$s = "SELECT amis FROM membres WHERE id='$id'"; // on cherche dans la BDD les photo du membre
		$quer = mysql_query($s) or die ("Requête incorrecte"); // resultat de la recherche
		$amis = mysql_fetch_array($quer);
		$amis = $amis['amis'];
		if($r != 1){
			echo"Ajouter comme ami ";
			echo"<form method=\"post\" action=\"index.php?p=pageMembre&page=".$tabInfo['login']."\"><input type=\"submit\" name=\"ajouterAmi\" value=\"Ajouter comme ami\"  /></form>";
			if(isset($_POST['ajouterAmi'])){

				$amis .= ",".$tabInfo['id'].",";
				mysql_query("UPDATE membres SET amis='$amis' WHERE id='$id' "); // on met a jour les scores du membre
				$idM = $tabInfo['id'];
				$notif = $tabInfo['notificationAmis'].','.$id.',';
				mysql_query("UPDATE membres SET notification='1' WHERE id='$idM' ");
				$sq = "INSERT INTO notification(id_user,type,id_notif) VALUES('$idM','0','$id')"; // on met la photo dans la BDD
				mysql_query($sq) or die('Erreur SQL !'.$sq.'<br />'.mysql_error()); //s'il y a une erreur
				redirection(mesAmis);

			}
		}
		else{
			echo"Il est votre ami<br/>";
		}

		if ($result > 0) { //si on a des résultats "$result est > 0"
			/*
				Dans le tableau $tabPhoto[][]
				le 1er [] est le numéro de la photo une ligne par photo
			*/
			$i=0; // N° de la ligne de notre tableau
			while ($row = mysql_fetch_array($query)) { //tant que qu'il rest des  resultat non traité
				$j=0; //colone de notre tableau
				$tabPhoto[$i][$j] = $row["id"]; //colone 0 le numéro de la photo dans la BDD
				$j++;
				$tabPhoto[$i][$j] = htmlentities($row["url"]);  //colone 1 l'url de la photo dans la BDD
				$j++;
				$tabPhoto[$i][$j] = htmlentities($row["nom_photo"]);  //colone 2 le nom de la photo dans la BDD
				$j++;
				$tabPhoto[$i][$j] = htmlentities($row["description"]); //colone 3 la description de la photo dans la BDD
				$j++;
				$tabPhoto[$i][$j] = htmlentities($row["+1"]);  //colone 4 le score de la photo dans la BDD
				$j++;
				$tabPhoto[$i][$j] = htmlentities($row["priver"]);  //colone 4 le score de la photo dans la BDD
				$j++;

				$tabPhoto[$i][$j] = $row["id_user"];  //colone 6 1 si la photo est privé dans la BDD
				$j++;

				$i++;
			}
			$_SESSION['photoAmis'] = $tabPhoto; // le tableau des photo est mis dans un variable de SESSION
			$size = sizeof($tabPhoto); // taille de notre tableau
				echo "<table id=\"tableauPhoto\">";
			echo"<CAPTION>Dernières Photos</CAPTION>";
			$i=0;

			while($i<$size){
				echo"<tr>";
				for($j=$i; $j<$i+5; $j++){// boucle pour afficher privé si c'est une photo privé
					if($tabPhoto[$j][5] == 1){
						echo "<td>privé</td>";
					}
					else echo "<td>".$tabPhoto[$j][6]."</td>";
				}
				echo"</tr>";

				echo"<tr>";
				for($j=$i; $j<$i+5; $j++){// boucle pour afficher les photo du membre
					echo "<td><a href=\"index.php?p=photoG&album=f&photo=".$j."\"><img class=\"miniature\" src=\"".$tabPhoto[$j][1]."\"></a></td>"; // on affiche la photo, clicable + un get du n° de la photo dans le tableau
				}
				echo"</tr>";
				echo"<tr>";
				for($j=$i; $j<$i+5; $j++){// boucle pour afficher les photo du membre
					echo "<th><a href=\"index.php?p=photoG&album=f&photo=".$j."\">".$tabPhoto[$j][2]."</a></th>"; //on affiche le nom de la photo
				}
				echo"</tr>";
				$i+=5;
			}

			echo "</table>";
		}
		else { // si on a pas de photo
			echo "l'utilisateur n'a pas de photo";
		}


	?>

</div>
