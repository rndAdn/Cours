<?php


	// on teste si le visiteur a soumis le formulaire
	if (isset($_POST['inscription']) && $_POST['inscription'] == 'Inscription') {
   	// on teste l'existence de nos variables. On teste Ã©galement si elles ne sont pas vides
		if (verifInscrption()) {// on verifie si les champs sont bien remplient
			connect(); // connection a la BDD
			mysql_query("SET NAMES 'utf8'");

			if (verifLogin()) { // on verifie que le login n'est pas dÃ©jÃ  utilisÃ©
				$mdp = motDePasse();// crÃ©ation d'un mot de passe alÃ©atoire
				$dateAmericaine = $_POST['annee']."-".$_POST['mois']."-".$_POST['jour']; //onn convertie la date de naissance en format amÃ©ricaine pour la BDD
				$dateInscription = date('Y-m-d');
				$sql = 'INSERT INTO membres(id, nom, prenom, login, mail, pwd, dateNaissance, dateInscription, score,sport, admin) VALUES("","'.mysql_escape_string($_POST['nom']).'", "'.mysql_escape_string($_POST['prenom']).'", "'.mysql_escape_string($_POST['login']).'", "'.mysql_escape_string($_POST['mail']).'", "'.mysql_escape_string(md5($mdp)).'","'.mysql_escape_string($dateAmericaine).'","'.mysql_escape_string($dateInscription).'","10", "'.mysql_escape_string($_POST['sport']).'","0")';//on inscrit le membre


				mysql_query($sql) or die('Erreur SQL !'.$sql.'<br />'.mysql_error());

				email($mdp); //on envoi un mail avec le mot de passe
				redirection("connexion"); // on retour a la page connexion

				}
			else {
				$erreur = 'Un membre possède déjà  ce login.';
			}

		}
		else {
			$erreur = 'Au moins un des champs est vide ou est mal renseigné';
		}
   }
?>
<div id="incription">
	<form method="post" action="index.php?p=inscription" >

			<table>
				<tr>
					<th>Nom</th>
					<td><input type="text" name="nom" /><br/></td>
				</tr>
				<tr>
					<th>PrÃ©nom</th>
					<td><input type="text" name="prenom" /></td>
				</tr>

				<tr>
					<th>Pseudo</th>
					<td><input type="text" name="login" /></td>
				</tr>

				<tr>
					<th>Date de naissance</th>
					<td>Jour : <input type="date" size="1" maxlength="2" name="jour"/>  Mois : <input type="date" size="1" maxlength="2" name="mois" />  AnnÃ©e : <input type="date" size="4" maxlength="4" name="annee" /></td>
				</tr>
				<tr>
					<th>Mail</th>
					<td><input type="address" name="mail" /></td>
				</tr>
				<tr>
					<th>Confirmer l'adresse Mail</th>
					<td><input type="address" name="mail2" /></td>
				</tr>
				<tr>
					<th>Quel est votre sport préféré</th>
					<td><select name="sport">
								<option value="surf">Surf</option>
								<option value="winsurf">Winsurf</option>
								<option value="kitesurf">Kitesurf</option>
								<option value="wakeboard">Wakeboard</option>
								<option value="snowboard">Snowboard</option>
								<option value="skate">Skate</option>
						</select>
					</td>
				</tr>
				<tr>
					<td><em>Tout les champs sont obligatoires</em><br/></td>
					<td><input type="submit" name="inscription" value="Inscription" /></td>
				</tr>
			</table>
			<br/>
		</form>

		<?php
			if (isset($erreur)) echo '<br />',$erreur; //afichage de l'ereur s'il en a eu une
		?>


</div>
