<?php

	f5();
	connect();
	$id = $_SESSION['id'];

	notification();
	$tabNotifications =array();
	$tabNotifications['amis'] = $_SESSION['notifAmis'];
	$tabNotifications['com'] = $_SESSION['notifCom'];



	echo "<h2>Notification Commentaires</h2><br/>";
	if(sizeof($tabNotifications['com'])> 0){
		echo"Connard";

		$size = sizeof($tabNotifications['com']);
		if($size > 1){
			echo "il y a des nouveaux commentaires sur ces photos";
		}
		else {
			echo "il y a un nouveau commentaire sur cette photo";
		}
		tabTTphoto();
		$tabPhoto = $_SESSION['toutesPhoto'];
		$size2 = sizeof($tabPhoto);
		echo "<table>";

		for($i=0;$i<$size;$i++){
			for($j=0;$j<$size2;$j++){
				if($tabPhoto[$j][0]==$tabNotifications['com'][$i][1]){
					echo "<tr>";
					echo "<td><a href=\"index.php?p=photoG&album=t&photo=".$j."\"><img class=\"miniature\" src=\"".$tabPhoto[$j][1]."\"></a></td>";
					echo "</tr>";
				}
			}
		}
		echo "</table>";
	}
	else{
		echo "Pas de nouveau commentaire";
	}


	echo "<br/><h2>Notification Amis<h2>";

	if(sizeof($tabNotifications['amis'])>0){
		echo"Connard";

		$size = sizeof($tabNotifications['amis']);
		if($size > 1){
			echo "Un nouveau membre vous a ajouter a sa liste d'amis";
		}
		else {
			echo "il y a un nouveau commentaire sur cette photo";
		}
		$tabMembre = array();
		for($i = 0; $i<sizeof($tabNotifications['amis']);$i++){
			$idM = $tabNotifications['amis'][$i][1];
			$reqNotifAmis = "SELECT avatar,nom,prenom,login FROM membres WHERE id='$idM'";
			$query = mysql_query($reqNotifAmis) or die('Erreur SQL !'.$sq.'<br />'.mysql_error()); //s'il y a une erreur
			$notif = mysql_fetch_array($query);
			$tabMembre[$i][0] = $notif['login'];
			$tabMembre[$i][1] = $notif['nom'];
			$tabMembre[$i][2] = $notif['prenom'];
			$tabMembre[$i][3] = $notif['avatar'];

		}

		echo "<table>";

		for($i=0;$i<sizeof($tabMembre);$i++){
			echo "<tr>";
			echo "<td><a href=\"index.php?p=pageMembre&page=".$tabMembre[$i][0]."\"><img class=\"photo_avatar\" src=\"".$tabMembre[$i][3]."\"></a></td>";
			echo "<td><a href=\"index.php?p=pageMembre&page=".$tabMembre[$i][0]."\">".$tabMembre[$i][2]." \"".$tabMembre[$i][0]."\" ".$tabMembre[$i][1]." </a></td>";
			echo "</tr>";
		}
		echo "</table>";
	}
?>
