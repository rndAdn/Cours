<?php
	if(!(isset($_SESSION['login']) && !empty($_SESSION['login']))){ // si on n'esdt pas connectÃ© on degage
			$_SESSION['err'] = "vous n'est pas connecté";
			print("<script type=\"text/javascript\">setTimeout('location=(\"index.php\")' ,1);</script>");
	}
?>
<div class="img">
	<a href="index.php?p=monCompte"><img class="photo_profile" src="<?php echo $_SESSION['avatar'];?>" ></a>
</div>
<div id="menu">
	<?php

		f5();
		$id = $_SESSION['id'];
		connect();
		$reponse = mysql_query("SELECT notification FROM membres WHERE id='$id'"); // on verifi si le membre et le mot de passe existe
		$donnees = mysql_fetch_array($reponse);//on crÃ©Ã© un petit tableau des rÃ©sultats (normalement, il y en a qu'un si t'as tout bien configurÃ© lors de l'inscription)

		$notif = $donnees['notification'];
	?>
	<ul>
		<form method="post" action="index.php?p=recherche" id="search" >
			<li><a href="index.php?p=monCompte&photo=2"><?php echo $_SESSION['login'];?></a></li>
			<li><a href="index.php?p=notification" <?php if($notif == 1){echo "id='notification'";}?>>Notification</a></li>
			<li><a href="index.php?p=mesPhotos">Mes Photos</a></li>
			<li><a href="index.php?p=mesAmis">Mes Amis</a></li>
			<li><a href="index.php?p=deconnexion">Déconnexion</a></li>
			<input name="recherche" type="text" size="40" placeholder="Rechercher..."  />
		</form>
	</ul>
</div>

