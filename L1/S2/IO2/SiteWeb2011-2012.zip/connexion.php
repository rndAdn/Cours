<?php

	$_SESSION['err']="";
	if (isset($_POST['connexion']) && $_POST['connexion'] == 'Connexion') { //si le formulaire est soumis
		if ((isset($_POST['login']) && !empty($_POST['login'])) && (isset($_POST['pwd']) && !empty($_POST['pwd']))) { // si les champs sont rempli
			 connect();


			$login = mysql_real_escape_string(htmlspecialchars($_POST['login']));

			$pwd = mysql_real_escape_string(htmlspecialchars(md5($_POST['pwd'])));



			$reponse = mysql_query("SELECT * FROM membres WHERE login='$login' AND pwd='$pwd'"); // on verifi si le membre et le mot de passe existe
			$donnees = mysql_fetch_array($reponse);//on crÃ©Ã© un petit tableau des rÃ©sultats (normalement, il y en a qu'un si t'as tout bien configurÃ© lors de l'inscription)


			if (($donnees['login']) AND ($donnees['pwd'])){//Si on a un resultat ... on a plus qu'a crÃ©er les session

				$date = date('Y-m-d H:i:s'); // date de connexion
				mysql_query("UPDATE membres SET dateConnexion='$date' WHERE login ='$login'"); // on met à jour la date de la derniere connexion

				$_SESSION['dateConnexion'] = $date;

				$_SESSION['id'] = $donnees['id'];
				$_SESSION['login'] = $_POST['login']; // Session contenant le login du membre
				$_SESSION['mail'] = $donnees['mail'];// Session contenant l'e-mail du membre
				$_SESSION['amis'] = $donnees['amis'];
				$_SESSION['nom'] = $donnees['nom'];
				$_SESSION['prenom'] = $donnees['prenom'];
				$_SESSION['dateNaissance'] = $donnees['dateNaissance'];
				$_SESSION['dateInscrption'] = $donnees['dateInscrption'];
				$_SESSION['score'] = $donnees['score'];
				$_SESSION['nombresPhotos'] = $donnees['nombresPhotos'];
				$_SESSION['nombresCom'] = $donnees['nombresCom'];
				$_SESSION['avatar'] = $donnees['avatar'];
				$_SESSION['admin'] = $donnees['admin'];
				mysql_close();
				redirection("monCompte");
				exit();

			}

			// si on ne trouve aucune rÃ©ponse, le visiteur s'est trompÃ© soit dans son login, soit dans son mot de passe
			else {
				 $erreur = 'le login ou le mot de passe est incorrecte';
			}
		}
		else $erreur = 'Au moins un des champs est vide.';
	}
?>
<div id="connexion">
	<form method="post" action="index.php?p=connexion" >

			<table>
				<tr>
					<th>Pseudo</th>
					<td><input type="text" name="login" /></td>
				</tr>

				<tr>
					<th>Mot de passe</th>
					<td><input type="password" name="pwd" /></td>
				</tr>
				<tr>
					<td> </td><td> </td>
				</tr>
				<tr>
					<th></th>
					<td><input type="submit" name="connexion" value="Connexion" /></td>
				</tr>
			</table>
			<br/>
		</form>
		<?php
			if (isset($erreur) && !empty($erreur)){
				echo $erreur;
			}
		?>

</div>
