<div id="photoG">
	<?php
	//<a href=\"index.php?p=photoG&album=".$album."&photo=".$j."\"><img class=\"".$class."\" src=\"".$tabPhoto[$j][1]."\"></a></td>"; // on affiche la photo, clicable + un get du nÂ° de la photo dans le tableau
	$num_photo = $_GET['photo'];


	$album = $_GET['album'];
	$tabPhoto = array();
	if($album == "d"){
		$tabPhoto= $_SESSION['dernierePhoto'];
	}
	elseif ($album == "t"){
		$tabPhoto= $_SESSION['toutesPhoto'];
	}
	elseif ($album == "m"){
		$tabPhoto= $_SESSION['MPhoto'];
	}
	elseif ($album == "r"){
		$tabPhoto= $_SESSION['recherchePhoto'];
	}
	elseif ($album == "f"){
		$tabPhoto= $_SESSION['photoAmis'];
	}
	elseif ($album == "l"){
		$tabPhoto= $_SESSION['LikePhoto'];
	}

	for($i = 0 ;$i <sizeof($_SESSION['notifCom']);$i++ ){
			//echo"YOYOYOYO";
			if($_SESSION['notifCom'][$i][1] ==  $tabPhoto[$num_photo][0]){
				$id_notif = $_SESSION['notifCom'][$i][0];
				echo $id_notif;
				mysql_query("DELETE FROM notification WHERE id ='$id_notif'");
			}
		}



	if($_POST['modiff'] == 'Modifier'){
		echo'
		<form method="post" action="index.php?p=photoG&album='.$album.'&photo='.$num_photo.'">
		URL de la photo <input type="text" name="photo" value="'.$tabPhoto[$num_photo][1].'"/><br />
		Quel est le sport de la photo<select name="sport">
								<option value="surf">Surf</option>
								<option value="winsurf">Winsurf</option>
								<option value="kitesurf">Kitesurf</option>
								<option value="wakeboard">Wakeboard</option>
								<option value="snowboard">Snowboard</option>
								<option value="skate">Skate</option>
						</select><br/>
		Titre de la photo<input type="text" name="titre" value="'.$tabPhoto[$num_photo][2].'""/><br/>
		<textarea rows="4" cols="50" name="description">'.$tabPhoto[$num_photo][3].'</textarea> <br/>
		<input type="checkbox" name="priver" value="priver" />Privé<br/>
		<input type="submit" name="modiff" value="Confirmer" />
		</form>';
	}
	elseif ($_POST['modiff'] == 'Confirmer'){
		connect();
		$id_photo = $tabPhoto[$num_photo][0];
		$titre = 	$_POST['titre']; //titre de la photo que l'on upload
		$url = $_POST['photo']; //url de la photo que l'on upload

		$description = $_POST['description']; //description de la photo que l'on upload

		$sport = $_POST['sport'];
		$priver = 0;
		if($_POST['priver']== "priver") $priver = 1;

		mysql_query("UPDATE photo SET url='$url', nom_photo='$titre', description='$description', priver='$priver', sport='$sport'  WHERE id ='$id_photo'");
		$_POST['modiff'] = 'Confirmer';
		affichageGrandePhoto($num_photo,$tabPhoto, $album);
	}
	else{
		affichageGrandePhoto($num_photo,$tabPhoto, $album);
		//AFFICHER +1/-1
		plus($tabPhoto[$num_photo][0],$album,$num_photo,$tabPhoto);
		echo'
		<form method="post" action="index.php?p=photoG&album='.$album.'&photo='.$num_photo.'">
		<input type="submit" name="modiff" value="Modifier" />
		</form>';
		posterCommentaire($tabPhoto[$num_photo][0],$album,$num_photo,$tabPhoto);

	}



	?>

</div>
