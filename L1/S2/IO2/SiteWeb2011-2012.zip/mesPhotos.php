<?php
	if(!(isset($_SESSION['login']) && !empty($_SESSION['login']))){
			$_SESSION['err'] = "vous n'est pas connectÃ©";
			print("<script type=\"text/javascript\">setTimeout('location=(\"index.php\")' ,1);</script>");
	}
?>
<div id="mesPhotos">
	<h2>Mes photos</h2>
	<?php


		// on affiche toutes les photos du membre
		connect();
		tabTTPhoto();
		tabDerPhoto();
		tabMPhoto();
		tabLikePhoto();
		$d = $_SESSION['dernierePhoto'];
		$t = $_SESSION['toutesPhoto'];
		$m = $_SESSION['MPhoto'];
		$l = $_SESSION['LikePhoto'];






		echo '<div id="tab">
					<div class="row">
						<div class="cell"><h3>Mes 4 dernieres photo</h3>';

		affichage4($d, "miniature","dernière","d");

				echo '</div>
					<div div class="cell"><h3>Mes 4 photo les plus aimées</h3>';

		affichage4($m, "miniature","Les plus aimées","m");

				echo '</div>
					</div>
					<div class="row">
						<div class="cell""><h3>Toutes mes photo</h3>';

		affichage4($t, "miniature","Toutes les photos","t");

					echo '</div>
						<div class="cell"><h3>Photo que j\'aime</h3>';

		affichage4($l, "miniature","Photo que j'aime","l");

		//Ajouter les photos que j'ai aimÃ©es
				echo '</div>
					</div>
			</div>';
	?>

	<?php



	if (isset($_POST['upload']) && $_POST['upload'] == 'Envoyer') {//si l'user a appuyer sur envoyer
		if(isset($_POST['photo']) && $_POST['photo'] != ""){
			if(isset($_POST['titre']) && $_POST['titre'] != 'Titre de la photo'){
				if(isset($_POST['description']) && $_POST['description'] != 'Desctiption de la photo'){
					if(isset($_POST['motCle']) && $_POST['motCle'] != 'Mot cles'){
						connect();

						/*
							tout les variable POST SESSION etc son mise dans des variable simple a changer
						*/
						$titre = 	$_POST['titre']; //titre de la photo que l'on upload
						$url = $_POST['photo']; //url de la photo que l'on upload
						$id = $_SESSION['id']; //id de l'user qui upload
						$description = $_POST['description']; //description de la photo que l'on upload
						$score = $_SESSION['score'] +1; // on ajoute + 1 au score du membre pour avoir uploader une photo
						$_SESSION['score'] = $score;
						$nbPhoto = $_SESSION['nombresPhotos'] +1; // on ajoute + 1 au nombre de photo uploader du membre evident
						$_SESSION['nombresPhotos'] = $nbPhoto;
						$sport = $_POST['sport'];
						$priver = 0;
						if($_POST['priver']== "priver") $priver = 1;

						/*
							ajouter l'envoi des mots clÃ©s et la date d'upload
						*/

						$motCle = $_POST['motCle'];
						$motCle = mb_strtoupper($motCle, "utf-8");

						$tabMot = explode(" ",$motCle);
						$size = sizeof($tabMot);
						$AjoutPhoto = "INSERT INTO photo(id_user, nom_photo, url, description, sport, priver) VALUES('$id','$titre', '$url','$description','$sport','$priver')"; // on met la photo dans la BDD
						mysql_query("UPDATE membres SET score='$score' , nombresPhotos='$nbPhoto' WHERE id ='$id'"); // on met a jour les scores du membre
						mysql_query($AjoutPhoto ) or die('Erreur SQL !'.$sql.'<br />'.mysql_error()); //s'il y a une erreur
						//AJOUTER OÃ™ MODIFIER LES MOTS CLÃ‰


						$id_photo = mysql_query("SELECT * FROM photo WHERE id_user='$id' AND nom_photo='$titre' AND url='$url'"); // on recupère l'id de la photo que l'on vien de poster normalement une seul ponse
						$do = mysql_fetch_array($id_photo);
						$id_photo = $do['id'];
						for($i=0; $i<$size ; $i++){
							$mot=$tabMot[$i];
							$repon = mysql_query("SELECT * FROM motsCles WHERE motscles='$mot'"); // on verifi si le membre et le mot de passe existe
							$result = mysql_numrows($repon); // nombre de rÃ©sultat
							if($result > 0){
								mysql_query("UPDATE motsCles SET id_photo=CONCAT(id_photo, ',$id_photo,') WHERE motscles ='$m'"); // on met a jour les scores du membre
							}
							else{

								$sq = "INSERT INTO motsCles(id_photo, motscles) VALUES(',$id_photo,','$m')"; // on met la photo dans la BDD
								mysql_query($sq) or die('Erreur SQL !'.$sq.'<br />'.mysql_error()); //s'il y a une erreur

							}

						}




						redirection("mesPhotos");

					}
					else{
						echo"Veuillez mettre au moins un mot clÃ©";
					}
				}
				else {
					echo"Veuillez mettre une description";
				}
			}
			else {
				echo"Veuillez mettre un titre a votre photo";
			}
		}
		else {
			echo"Veuillez mettre l'url de votre photo";
		}
	}
?>
	<form method="post" action="index.php?p=mesPhotos" >
		<h2>Ajouter une photo</h2>
		URL de la photo <input type="text" name="photo"/><br />
		Quel est le sport de la photo<select name="sport">
								<option value="surf">Surf</option>
								<option value="winsurf">Winsurf</option>
								<option value="kitesurf">Kitesurf</option>
								<option value="wakeboard">Wakeboard</option>
								<option value="snowboard">Snowboard</option>
								<option value="skate">Skate</option>
						</select><br/>
		Titre de la photo<input type="text" name="titre" value="Titre de la photo"/><br/>
		Mots clés<input type="text" name="motCle" value="Mot cles"/><br/>
		!!ATTENTION!! vous ne pourrez plus modifier les mots clés<br/>
		<textarea rows="4" cols="50" name="description">Desctiption de la photo</textarea> <br/>
		<input type="checkbox" name="priver" value="priver" />Privé<br/>
     <input type="submit" name="upload" value="Envoyer" />
	</form>
</div>

