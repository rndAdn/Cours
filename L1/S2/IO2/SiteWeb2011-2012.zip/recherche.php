<div>
	<?php
		$and = "AND";
		$or = "OR";
		// $motcle = explode(" ",$_POST['recherche']);
		if(isset($_POST['recherche']) && ($_POST['recherche'] != "" && $_POST['recherche'] != " ")) {


			$mot = $_POST['recherche'];
			$mot = mb_strtoupper($mot, "utf-8");

			$tabMot = explode(" ",$mot);
			$size = sizeof($tabMot);
			// echo $size;
			// echo $mot."<br/>";
			$tabPhoto = array();
			for($i = 0 ; $i<$size ; $i++){
				$mot = $tabMot[$i];
				$rep = mysql_query("SELECT * FROM motsCles WHERE motscles LIKE '$mot%'"); // on verifi si le membre et le mot de passe existe
				$do = mysql_fetch_array($rep);
				$a = explode(",", $do['id_photo']);
				//echo $do['id_photo'];
				$size2 = sizeof($a);
				$j =0;

				for($k = 0; $k<$size2 ; $k++){
					if($a[$k] != "" && $a[$k] != " " && $a[$k] != ","){
						$tabPhoto[$i][$j] = $a[$k];
						$j++;
					}
				}

			}


			//print_r ($tabPhoto);
			$photo = array();
			$min = sizeof($tabPhoto[0]);
			$num = 0;
			$size = sizeof($tabPhoto);
			for($i = 0 ; $i < $size ; $i++){
				if($min > sizeof($tabPhoto[$i])){
					$min = sizeof($tabPhoto[$i]);
					$num = $i;
				}
			}
			$min = $tabPhoto[$num];
			$tmp = 0;
			for ($i = 0; $i < sizeof($min); $i++ ){

				$yyes =TRUE;
				for ($j = 0; $j < sizeof($tabPhoto); $j++) {
					$yes = FALSE;
					for ($k = 0; $k < sizeof($tabPhoto[$j]); $k++) {
						if ($tabPhoto[$j][$k] == $min[$i]) {
							$yes = TRUE;
						}
					}
					if (!$yes) {
						$yyes = FALSE;
						break;
					}
					else{
						$photo[$tmp] = $min[$i];
						$tmp++;
					}
				}
			}
			//print_r($photo)
			tabRecherchePhoto($photo);
			$d = $_SESSION['recherchePhoto'];
			//print_r($mot);
			//Recheche des membres
			
			$tabMembre = array();
			tabRechercheMembre($tabMot);
			$tabMembre = $_SESSION['rechercheMembre'];
			//print_r($tabMembre);


		}

		else{
			echo"veuillez entrer au moins un mot pour la recherche";
		}

	?>
	<h1>Membres</h1>
	<p>Recherche des membres avec leurs noms, prénom et/ou login</p>
	<?php
	$size = sizeof($tabMembre);
	if($size == 0){
		echo '<p>La recherche n\'a retourné aucun résultat</p>';
	}else {
		affichageMembre($tabMembre);
	}
	?>

	<h1>Photos</h1>
	<?php
		affichage4($d, "miniature","résultat","r");
	?>
</div>
