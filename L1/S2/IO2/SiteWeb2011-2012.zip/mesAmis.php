<?php
	if(!(isset($_SESSION['login']) && !empty($_SESSION['login']))){
			$_SESSION['err'] = "vous n'est pas connecté";
			print("<script type=\"text/javascript\">setTimeout('location=(\"index.php\")' ,1);</script>");
	}

	f5();

?>
<div id="mesAmis">
	<h2>Amis qui sont dans ma liste</h2>
		<?php
			$id = $_SESSION['id'];

			$amis = explode(",", $_SESSION['amis']);
			$tabA = array();
			$j =0;
			for($i =0; $i<sizeof($amis) ; $i++){
				if($amis[$i] != "" && $amis[$i] != " " && $amis[$i] != ","){
					$tabA[$j] = $amis[$i];
					$j++;
				}
			}
			echo "<table>";
			for($i =0; $i<sizeof($tabA) ; $i++){
				$idM = $tabA[$i];
				connect();
				$reqAmis = "SELECT * FROM membres WHERE id='$idM'"; // on cherche dans la BDD les photo du membre
				$query = mysql_query($reqAmis) or die ("Requète incorrecte"); // resultat de la recherche
				$tab=mysql_fetch_array($query);

				echo "<tr>";
				echo "<td><img class=\"mini\" src=\"".$tab['avatar']."\"></td>";
				echo "<td><a href=\"index.php?p=pageMembre&page=".$tab['login']."\">".$tab['login']."</a></td>";
				if(isset($_POST['supprimer'])){
					echo "<td><form method=\"post\" action=\"index.php?p=mesAmis\" > <input type=\"submit\" name=\"".$idM."\" value=\"Supprimer ".$tab['login']."\" /></form></td>";
				}
			}
			$amiS ="";
			echo "</table>";
			
			for($i = 0; $i<sizeof($tabA); $i++){
				$idM = $tabA[$i];
				if(isset($_POST[$idM])){
					$tabA[$i]= "";
				}
				else {
					$amiS .= ",".$idM.",";
				}
			}
			$_SESSION['amis'] = $amis;
			connect();
			mysql_query("UPDATE membres SET amis='$amiS' WHERE id ='$id'"); // on met a jour les scores du membre

		?>
		<form method="post" action="index.php?p=mesAmis" >
		<input type="submit" name="supprimer" value="Supprimer un ami" />
		</form>

		<h2>Amis dont je suis dans la liste</h2>

		<?php


			$AmisDansMaListe = mysql_query("SELECT * FROM membres WHERE amis LIKE '%,$id,%'"); // on verifi si le membre et le mot de passe existe


			$result = mysql_numrows($AmisDansMaListe) or die ("Requète incorrecte");// nombre de rÃ©sultat


			$tabAmis=array(); // tableau (2D) qui contiendra les photo du membre




			if ($result > 0) { //si on a des rÃ©sultats "$result est > 0"
			/*
				Dans le tableau $tabPhoto[][]
				le 1er [] est le numÃ©ro de la photo une ligne par photo
			*/

			$i=0; // NÂ° de la ligne de notre tableau
			while ($row = mysql_fetch_array($AmisDansMaListe)) { //tant que qu'il rest des  resultat non traitÃ©
				$j=0; //colone de notre tableau
				$tabAmis[$i][$j] = $row["nom"]; //colone 0 le numÃ©ro de la photo dans la BDD
				$j++;
				$tabAmis[$i][$j] = $row["prenom"];  //colone 1 l'url de la photo dans la BDD
				$j++;
				$tabAmis[$i][$j] = $row["login"];  //colone 2 le nom de la photo dans la BDD
				$j++;
				$tabAmis[$i][$j] = $row["avatar"]; //colone 3 la description de la photo dans la BDD
				$j++;
				$tabAmis[$i][$j] = $row["sport"]; //colone 3 la description de la photo dans la BDD
				$j++;
				$i++;
			}
			$_SESSION['autreAmis'] = $tabAmis;
		}
		echo '<table>';

		for($i=0 ; $i<sizeof($tabAmis) ; $i++){
			echo '<tr>';
			echo '<td><a href="index.php?p=pageMembre&page='.$tabAmis[$i][2].'"><img class="mini" src="'.$tabAmis[$i][3].'"></a></td>';
			echo '<td><a href="index.php?p=pageMembre&page='.$tabAmis[$i][2].'">'.$tabAmis[$i][0].' "'.$tabAmis[$i][2].'" '.$tabAmis[$i][1].'</a></td>';
			echo '<tr>';
		}
		echo '</table>';
		?>

</div>


